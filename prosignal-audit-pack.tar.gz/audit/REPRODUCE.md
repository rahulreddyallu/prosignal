# ProSignal audit — reproduction pack

Every number in the dossier came from these scripts, run against the live
curated store at commit `a359622`. Nothing is estimated or inferred from the
documentation.

## Setup

```bash
git clone https://github.com/rahulreddyallu/prosignal.git
cd prosignal && pip install -r requirements.txt && pip install --no-deps -e .

mkdir -p ~/audit && cp experiments/*.py ~/audit/
mkdir -p ~/audit/config && cp config/parameters.yaml ~/audit/config/
ln -s /path/to/your/data ~/audit/data          # the real curated store
export PROSIGNAL_HOME=~/audit
cd ~/audit
```

`lab.py` caches two artefacts under `/home/claude/work/cache` (edit `CACHE` to
taste): `matrices.pkl` (~190 MB, all price pivots) and `panel_prod.parquet`
(the production training panel, 88 dates × 46,364 rows). The first build takes
about three minutes; everything afterwards is seconds.

## Scripts, in the order they were run

| script | what it establishes | key output |
|---|---|---|
| `e1_fit.py` | The production model reproduces exactly from the store | all 7 λ and t to 4 dp, `n_train` 43,555, `n_dates` 83 |
| `e2_inference.py` | **F3** — the gate uses NW-2 (VIF 1.44–1.99) where `analytic_vif` gives 2.97; `lottery_f` fails at |t| ≥ 2 under the repo's own preferred correction | theme-by-theme t comparison |
| `e3_panel_facts.py` | **W3, W5** and the standalone factor registry | sector-mixture shares, 5 dead delivery dates, IC/ICIR/adj-t per factor |
| `e4_staleness.py` | **F2** — live features are 4 sessions stale; costs 0.14pp of excess and 36% of the shortlist | IC/excess/top-8 agreement at lags 0,1,2,4,8 |
| `e5_cpcv.py` | **F1** — the Deflated Sharpe under five different accountings of *n* and `sr_var` | DSR 1.000 → 0.465 → 0.148 → 0.000 |
| `e6_ablation.py` | First-pass ablation (contains the gate-selection trap — see `e7`) | ranking + book metrics per configuration |
| `e7_ablation2.py` | The corrected ablation: excess `t` on **distinct dates**, exposure reported | `mom+delivery` best on every measure |
| `e8_placebo.py` | **S2** — the null test the repo never ran | random rankers Sharpe ≈ 0.00; inverted momentum −0.39 |
| `e9_beta_convexity.py` | **W1** — label vs book-outcome rank correlation 0.531; exit-side distribution | 39% invalidation / 32% stop / 18% target |
| `e10_structure.py` | Factor correlation, PCA, and the ablation redone with the gate **off** | participation ratio 5.21 of 7; the `beta alone` artefact |
| `e11_attribution.py` | **The alpha question** — regression on the engine's own long-short factors | alpha vs momentum alone +0.06% (t +0.08) |
| `e12_rebalance.py` | Continuous-book simulator at 21 / 42 / 63-session cadence | CAGR −0.8% to +4.9%; max DD −20% to −27% |
| `e13_regimes.py` | **The benchmark comparison** and the regime split | book +3.4% vs Nifty200 Momentum 30 +16.2%; COVID −4.6% vs −34.7% |
| `mutate.py`, `mutate2.py` | Mutation probe of the test suite | 10 of 16 injected defects caught, 6 survived |

## The four experiments that decide the verdict

1. **`e13_regimes.py`** — the book against the equal-weight universe, Nifty 200
   and Nifty200 Momentum 30 over the exact selection window. There is no
   benchmark anywhere in `portfolio_sim`, `harness` or `backtest`; this adds one.
2. **`e5_cpcv.py`** — the DSR arithmetic taken apart. Note especially that
   `trial_sharpes` is never passed by any caller in `src/`, and that
   `result.path_sharpes` is the right input sitting unused in the same object.
3. **`e4_staleness.py`** — run this first if you only run one. It confirms the
   live feature date against the store in about ten lines.
4. **`e7_ablation2.py`** — the theme-by-theme evidence ledger, with the two
   confounds (pooled-`n` t-statistics, unadjusted exposure) removed.

## Two traps worth knowing about

- **Single-theme arms under a gated estimator are scored on selected splits.**
  `fit_coefficients` returns `None` when no theme clears the floor, so a
  one-theme arm only trades on splits where it happened to measure. With one
  theme, `hierarchical_shrink` also drives τ² to zero whenever |t| ≤ 1, so this
  bites even at `significance_floor=0`. `configuration_matrix` documents the
  trap for PBO; `e6` walks into it and `e10` measures the size of the artefact
  (`beta alone`: IC −0.105 / net +1.43% gated, IC −0.016 / net −1.25% ungated).

- **`mutate.py` restores each file in a `finally`.** If you interrupt it, run
  `git checkout -- src/` before trusting anything.

## Environment

Python 3.11, pandas 2.2.3, numpy 2.0.2, pyarrow 25.0.1, pydantic 2.13.3.
Store: 2,212 sessions, 3,545 symbols, 2017-09-08 → 2026-08-25.
Full suite at HEAD: 1,343 passed, 1 failed, 49 skipped (the failure is
`test_ready_freshness.py::test_latest_session_is_reported_on_every_branch`,
which cannot pass on an empty store).
