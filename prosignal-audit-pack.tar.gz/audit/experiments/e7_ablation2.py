"""E7: the same ablation, with the two confounds removed.

1. The excess t must be computed on DISTINCT dates, not on pooled (split, date)
   pairs -- the same inflation the engine's own DSR suffers from.
2. Book Sharpe is not exposure-adjusted. A configuration that deploys 40% of
   capital and one that deploys 85% are not comparable on Sharpe, which is the
   error the volatility-scaling section correctly identifies and the ablation
   does not apply to itself.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.validation.portfolio_sim import PortfolioParams, simulate
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.validation.significance import newey_west_t
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sessions = store.price_sessions()
sel = p[p["date"] < pd.Timestamp(sessions[-378])].copy()
panels = pickle.loads((CACHE / "sim_panels.pkl").read_bytes())
model = CostModel(cfg)
def cost_bps(price, q, adtv):
    if price <= 0 or q <= 0: return 0.0
    return float(model.round_trip(price, int(max(q, 1)), adtv_inr=adtv if adtv > 0 else None).total_bps_of_buy)
cap, c6, c7 = cfg.params.capital, cfg.params.stage6_entry, cfg.params.stage7_risk
PARAMS = PortfolioParams(
    cost_fn=cost_bps, capital=fv(cap.total_capital_inr),
    max_positions=iv(cap.max_open_positions),
    risk_per_trade_pct=fv(cap.risk_per_trade_pct),
    max_participation_of_adtv=fv(cap.max_participation_of_adtv),
    stop_atr_multiple=fv(c7.stop_loss.atr_multiple),
    min_stop_distance_pct=fv(c7.stop_loss.min_stop_distance_pct),
    max_stop_distance_pct=fv(c7.stop_loss.max_stop_distance_pct),
    invalidation_ma_sessions=iv(c7.thesis_invalidation.structure_ma_sessions),
    invalidation_buffer_atr=fv(c7.thesis_invalidation.structure_buffer_atr),
    horizon_sessions=63, entry_rank=iv(c6.admission.entry_rank),
    exit_rank=iv(c6.admission.exit_rank))

CONF = {"ALL 7 (shipped)": features,
        "mom alone": ["mom_f"],
        "delivery alone": ["delivery_f"],
        "beta alone": ["beta_f"],
        "mom+delivery": ["mom_f", "delivery_f"],
        "mom+delivery+lottery": ["mom_f", "delivery_f", "lottery_f"],
        "drop mom": [c for c in features if c != "mom_f"],
        "drop delivery": [c for c in features if c != "delivery_f"],
        "drop lottery": [c for c in features if c != "lottery_f"]}

cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2, label_horizon=3, embargo=1)
dates = sorted(sel["date"].unique())
by_date = {d: g for d, g in sel.groupby("date")}
splits = list(cv.split(len(dates)))

hdr = (f"{'configuration':<26}{'IC':>9}{'exc/date':>10}{'t(NW,n=dates)':>15}"
       f"{'net':>8}{'gross':>8}{'deploy':>8}{'ret/deploy':>11}{'SR':>7}{'SR/dep':>8}{'newpos':>7}")
print(hdr); print("-" * len(hdr), flush=True)
out = []
for name, cols in CONF.items():
    pred_by_date, exc_by_date = {}, {}
    ic_by_date = {}
    for sp in splits:
        tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
        if len(tr) < 2000: continue
        fit, _fm, _w = fit_coefficients(tr, cols, estimator="fama_macbeth", horizon=63, step=21)
        if fit is None: continue
        for i in sp.test_idx:
            d = dates[i]; te = by_date[d]
            pr = predict(fit, te[cols].to_numpy("float64"))
            labv = te["label"].to_numpy("float64")
            ok = np.isfinite(pr) & np.isfinite(labv)
            if ok.sum() < 40: continue
            r = pd.Series(pr[ok]).rank(pct=True).to_numpy()
            top = r >= 0.90
            if top.any():
                exc_by_date.setdefault(d, []).append(float(labv[ok][top].mean() - labv[ok].mean()))
            ic_by_date.setdefault(d, []).append(
                lab.rank_ic(pr[ok], te["label_rank"].to_numpy("float64")[ok]))
            pred_by_date.setdefault(d, []).append(pd.Series(pr, index=te["symbol"].to_numpy()))
    if not exc_by_date:
        print(f"{name:<26}  estimator refused on every split"); continue
    dser = pd.Series({d: float(np.mean(v)) for d, v in exc_by_date.items()}).sort_index()
    icser = pd.Series({d: float(np.nanmean(v)) for d, v in ic_by_date.items()}).sort_index()
    t = newey_west_t(dser.to_numpy(), horizon_sessions=63, step_sessions=21).adjusted_t
    rankings = [(pd.Timestamp(d), pd.concat(v, axis=1).mean(axis=1).sort_values(ascending=False))
                for d, v in sorted(pred_by_date.items())]
    rs = [simulate(rankings, panels, PARAMS, phase=ph, step_sessions=21) for ph in range(3)]
    per = pd.concat([r.periods for r in rs if not r.empty], ignore_index=True)
    if per.empty: continue
    dep = per["deployed_frac"].mean()
    net, gross = per["ret"].mean(), per["gross_ret"].mean()
    sd = per["ret"].std(ddof=1)
    sr = net / sd * 2.0 if sd > 0 else np.nan
    print(f"{name:<26}{icser.mean():>+9.4f}{dser.mean():>+10.2%}{t:>+15.2f}"
          f"{net:>+8.2%}{gross:>+8.2%}{dep:>8.0%}{net/dep:>+11.2%}{sr:>+7.2f}"
          f"{sr/dep:>+8.2f}{per['n_new'].mean():>7.1f}", flush=True)
    out.append(dict(config=name, ic=icser.mean(), excess=dser.mean(), t=t, net=net,
                    gross=gross, deploy=dep, sr=sr, n_dates=len(dser)))
print(f"\nexcess t is on {len(dser)} distinct dates, Newey-West with the analytic")
print("overlap inflation -- not on the pooled split x date vector.")
pd.DataFrame(out).to_csv(CACHE / "ablation2.csv", index=False)
