"""Facts about the shipped panel that the documentation does not state."""
import numpy as np, pandas as pd, json
from pathlib import Path
import lab
from prosignal.features.crosssec import FEATURES, NEUTRAL_WHEN_MISSING

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
prod = p[p['date'] <= '2026-02-11'].copy()
print(f"panel {len(prod):,} rows / {prod['date'].nunique()} dates\n")

# ---------------------------------------------------------------- E8 delivery
print("=== E8  delivery: dates where the family is a constant ===")
for col in ("deliv_pct_r", "deliv_trend_r", "delivery_f"):
    if col not in prod: continue
    g = prod.groupby("date")[col].std()
    zero = (g < 1e-12).sum()
    print(f"  {col:<16} {zero:>3} of {len(g)} dates have zero cross-sectional variance")
d0 = prod.groupby("date")["delivery_f"].std()
dead = d0[d0 < 1e-12].index
if len(dead):
    print(f"  dead dates run {min(dead).date()} -> {max(dead).date()}")
print(f"  => delivery contributes an exactly-zero slope on {len(dead)} of "
      f"{prod['date'].nunique()} cross-sections, which enter its mean and its "
      f"Newey-West standard error as if they were measurements.\n")

# recompute delivery lambda excluding the dead dates
from prosignal.features.famamacbeth import fama_macbeth
live = prod[~prod["date"].isin(dead)]
fm_all = fama_macbeth(prod, features, horizon=63, step=21)
fm_live = fama_macbeth(live, features, horizon=63, step=21)
print(f"  {'theme':<12}{'all dates':>12}{'t':>7}{'  |':>4}{'delivery-live':>15}{'t':>7}")
for c in features:
    print(f"  {c:<12}{fm_all.lam[c]:>+12.4f}{fm_all.t_stat[c]:>+7.2f}    "
          f"{fm_live.lam[c]:>+15.4f}{fm_live.t_stat[c]:>+7.2f}")
print(f"  (dates: {fm_all.n_dates} vs {fm_live.n_dates})\n")

# ---------------------------------------------------------------- E7 sectors
print("=== E7  sector-neutral ranking: how much of the column is which ===")
if "sector" in prod.columns:
    have = prod["sector"].notna() & ~prod["sector"].astype(str).isin(["", "Unknown", "None"])
    print(f"  rows with a sector label: {have.mean():.1%}")
    per = prod[have].groupby(["date", "sector"]).size()
    big = per[per >= 12]
    ranked_within = big.groupby(level=0).sum()
    tot = prod.groupby("date").size()
    share = (ranked_within / tot).dropna()
    print(f"  share of names ranked WITHIN sector, per date: "
          f"median {share.median():.1%}  min {share.min():.1%}  max {share.max():.1%}")
    print(f"  => the remaining {1-share.median():.0%} carry a UNIVERSE rank in the "
          f"same column. The two are different quantities mixed into one factor.")
    # does the mixture bias the tails?
    d = prod[prod["date"] == prod["date"].max()].copy()
    d["_within"] = False
    cnt = d.groupby("sector").size()
    ok = set(cnt[cnt >= 12].index)
    d.loc[d["sector"].isin(ok), "_within"] = True
    top = d.nlargest(max(len(d)//10, 10), "mom_f")
    print(f"  on the last date: {d['_within'].mean():.0%} of the universe is "
          f"within-sector ranked, but only {top['_within'].mean():.0%} of the "
          f"top mom_f decile is.")
print()

# ---------------------------------------------------------------- E6 |label|
print("=== E6  the |label| < 1.0 filter (right-tail censoring) ===")
m = lab.matrices()
close = m["close"].astype("float64")
cfg, _ = lab.context()
elig = lab.eligible_mask(close, m["turnover"].astype("float64"), cfg)
dates = list(close.index)
from prosignal.features.crosssec import MIN_LOOKBACK
kept = dropped_hi = 0
for i in range(MIN_LOOKBACK, len(dates) - 63, 21):
    fwd = close.iloc[i + 63] / close.iloc[i] - 1.0
    e = elig.iloc[i].reindex(fwd.index).fillna(False)
    fwd = fwd[e.to_numpy() & np.isfinite(fwd)]
    kept += (fwd.abs() < 1.0).sum()
    dropped_hi += (fwd >= 1.0).sum()
print(f"  eligible labelled rows: {kept + dropped_hi:,}")
print(f"  removed by |label| < 1.0: {dropped_hi:,} ({dropped_hi/(kept+dropped_hi):.2%})")
print(f"  every one of them is a name that MORE THAN DOUBLED inside the label "
      f"window. The filter is conditioned on the outcome.\n")

# ---------------------------------------------------------------- factor ICs
print("=== standalone factor rank IC over the shipped panel ===")
cols = [f + "_r" for f in FEATURES]
out = []
for c in cols:
    if c not in prod.columns: continue
    ics = prod.groupby("date").apply(
        lambda g: lab.rank_ic(g[c].to_numpy("float64"),
                              g["label"].to_numpy("float64")), include_groups=False)
    ics = ics.dropna()
    if len(ics) < 5: continue
    from prosignal.validation.significance import newey_west_t
    o = newey_west_t(ics.to_numpy(), horizon_sessions=63, step_sessions=21)
    out.append(dict(factor=c[:-2], ic=ics.mean(), icir=ics.mean()/ics.std(ddof=1),
                    t_naive=o.naive_t, t_adj=o.adjusted_t, n=len(ics),
                    hit=float((ics > 0).mean())))
df = pd.DataFrame(out).sort_values("ic", ascending=False)
print(df.to_string(index=False, float_format=lambda v: f"{v:+.4f}"))
print()
print("=== family IC ===")
out = []
for c in features:
    ics = prod.groupby("date").apply(
        lambda g: lab.rank_ic(g[c].to_numpy("float64"),
                              g["label"].to_numpy("float64")), include_groups=False).dropna()
    from prosignal.validation.significance import newey_west_t
    o = newey_west_t(ics.to_numpy(), horizon_sessions=63, step_sessions=21)
    out.append(dict(family=c, ic=ics.mean(), icir=ics.mean()/ics.std(ddof=1),
                    t_adj=o.adjusted_t, n=len(ics), hit=float((ics > 0).mean())))
print(pd.DataFrame(out).to_string(index=False, float_format=lambda v: f"{v:+.4f}"))
