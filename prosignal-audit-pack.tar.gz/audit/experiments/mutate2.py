"""Re-run the mutations whose 'CAUGHT' verdict was the pre-existing red test.

`test_ready_freshness.py::test_latest_session_is_reported_on_every_branch` fails
on any empty store, so with `-x` it masked whatever the mutation did or did not
break. Deselected here, and the full suite is run so the count is real.
"""
import subprocess, sys, re
from pathlib import Path

SRC = Path("/home/claude/prosignal/src/prosignal")
DESELECT = ["--deselect",
            "tests/test_ready_freshness.py::test_latest_session_is_reported_on_every_branch"]
MUT = [
    ("BASELINE (no mutation)", "costs.py", "__all__", "__all__"),
    ("universe screen is no longer point-in-time",
     "features/crosssec.py",
     "    adtv = turnover.rolling(int(lookback_sessions), min_periods=1).median()",
     "    adtv = turnover.expanding(min_periods=1).median()"),
    ("training no longer stops a horizon before the decision date",
     "features/crossmodel.py",
     "    train_close = hist.iloc[: len(hist) - H]",
     "    train_close = hist"),
    ("DSR always returns 1.0",
     "validation/metrics.py",
     "    dsr = probabilistic_sharpe_ratio(arr, benchmark_sr=benchmark, observed_sr=observed)",
     "    dsr = 1.0"),
    ("stop distance clip removed",
     "features/exits.py",
     "        return np.clip(raw, self.min_stop_distance_pct,\n"
     "                       self.max_stop_distance_pct) / 100.0",
     "        return raw / 100.0"),
    ("live scoring uses features from the decision date (the CURRENT bug, fixed)",
     "features/crossmodel.py",
     "    live_hist = hist[live_cols].tail(MIN_LOOKBACK + 5)",
     "    live_hist = hist[live_cols].tail(MIN_LOOKBACK + 1)"),
    ("sector-neutral ranking removed (universe rank everywhere)",
     "features/crosssec.py",
     "    universe = cross_sectional_rank(values)\n    if sectors is None:\n        return universe",
     "    universe = cross_sectional_rank(values)\n    if True:\n        return universe"),
    ("uniqueness weights removed from the fit",
     "features/crossmodel.py",
     "    if uniqueness_weighting and \"uniqueness\" in panel.columns:",
     "    if False and \"uniqueness\" in panel.columns:"),
    ("delivery ranks neutral instead of raising when the panel is empty",
     "stages/stage4_core_score.py",
     "        if dl is None or dl.empty or \"deliv_pct\" not in dl.columns:",
     "        if False:"),
    ("corporate-action adjustment silently skipped",
     "data/store.py",
     "            adjusted = apply_adjustments(frame, actions, price_columns=price_cols)",
     "            adjusted = frame.copy()"),
]

def run():
    r = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "--tb=no",
                        "-p", "no:cacheprovider"] + DESELECT,
                       cwd="/home/claude/prosignal", capture_output=True,
                       text=True, timeout=1200)
    out = r.stdout + r.stderr
    names = [l.split(" ")[1] if " " in l else l
             for l in out.splitlines() if l.startswith("FAILED")]
    m = re.search(r"(\d+) failed", out)
    return (int(m.group(1)) if m else 0), names

print(f"{'mutation':<62}{'failed':>7}  first failures")
print("-" * 120, flush=True)
for name, rel, old, new in MUT:
    path = SRC / rel
    orig = path.read_text()
    if old != new:
        if old not in orig:
            print(f"{name:<62}{'PATTERN NOT FOUND':>7}"); continue
        path.write_text(orig.replace(old, new, 1))
    try:
        n, names = run()
    finally:
        path.write_text(orig)
    tag = "BASELINE" if old == new else ("CAUGHT" if n else ">>> SURVIVED <<<")
    print(f"{name:<62}{n:>7}  {tag}  {', '.join(x.split('::')[-1][:38] for x in names[:3])}",
          flush=True)
