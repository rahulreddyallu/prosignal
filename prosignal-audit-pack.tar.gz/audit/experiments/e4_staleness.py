"""E4: the live path scores from features 4 sessions before the decision date.

`fit_predict` and `today_features` both call
    build_panel(hist.tail(MIN_LOOKBACK + 5), horizon=1, step=21)
whose loop is  range(MIN_LOOKBACK, len(dates) - horizon, step).
With len = MIN_LOOKBACK + 5 and horizon = 1 the only reachable i is
MIN_LOOKBACK, which is 4 rows before the end. It is structurally impossible
for that loop to reach the last row at any horizon >= 1.

This measures what the staleness costs.
"""
import numpy as np, pandas as pd, json
from pathlib import Path
import lab
from prosignal.features import crosssec as cs
from prosignal.features import crossmodel as cm
from prosignal.features.crosssec import MIN_LOOKBACK, FEATURES, NEUTRAL_WHEN_MISSING
from prosignal.validation.significance import newey_west_t

CACHE = Path("/home/claude/work/cache")
LAGS = [0, 1, 2, 4, 8]
m = lab.matrices()
cfg, store = lab.context()
close = m["close"].astype("float64"); turnover = m["turnover"].astype("float64")
elig = lab.eligible_mask(close, turnover, cfg)
k = elig.any(axis=0); keep = k[k].index
close = close[keep]; turnover = turnover[keep]; elig = elig[keep]
deliv = m["delivery"].astype("float64").reindex(columns=keep)
sectors = m["sectors"]
dates = list(close.index)
bench_src = close.where(elig)
bench_full = bench_src.mean(axis=1).pct_change(fill_method=None).to_numpy("float64")

f = CACHE / "staleness.parquet"
if f.exists():
    allrows = pd.read_parquet(f)
else:
    rows = []
    idxs = list(range(MIN_LOOKBACK + max(LAGS), len(dates) - 63, 21))
    for n, i in enumerate(idxs):
        fwd = close.iloc[i + 63] / close.iloc[i] - 1.0
        e = elig.iloc[i]
        for L in LAGS:
            j = i - L
            feats = cs._features_at(close, turnover, j, bench_full[: j + 1],
                                    delivery=deliv)
            feats = feats[e.reindex(feats.index).fillna(False).to_numpy()]
            feats = feats.assign(label=fwd.reindex(feats.index))
            feats = feats[np.isfinite(feats["label"]) & feats["label"].abs().lt(1.0)]
            req = [c for c in FEATURES if c not in NEUTRAL_WHEN_MISSING]
            feats = feats.dropna(subset=req, thresh=int(len(req) * 0.7))
            if len(feats) < 40:
                continue
            feats["symbol"] = feats.index
            feats["sector"] = feats.index.map(sectors)
            for fac in FEATURES:
                r = cs.sector_neutral_rank(feats[fac], feats["sector"])
                feats[fac + "_r"] = r.fillna(0.0) if fac in NEUTRAL_WHEN_MISSING else r
            feats["lag"] = L
            feats["date"] = dates[i]
            rows.append(feats.reset_index(drop=True))
        if n % 10 == 0:
            print(f"  {n}/{len(idxs)}", flush=True)
    allrows = pd.concat(rows, ignore_index=True)
    allrows.to_parquet(f)

print(f"rows {len(allrows):,}  dates {allrows['date'].nunique()}\n")
members = [c for c in cm.FEATURE_COLUMNS if c in allrows.columns]
cm.build_families(allrows, members)

live = json.load(open("/home/claude/work/data/curated/crosssec_model.json"))
cols = live["features"]
mu = np.array(live["mu"]); sd = np.array(live["sd"])
coef = np.array([live["coef"][c] for c in cols])

print(f"{'lag':>4}{'rank IC':>10}{'ICIR':>8}{'adj t':>8}{'top-dec excess':>16}{'hit':>7}"
      f"{'  turnover of top 8':>20}")
base_top = {}
res = {}
for L in LAGS:
    sub = allrows[allrows["lag"] == L]
    ics, exs, tops = [], [], {}
    for d, g in sub.groupby("date"):
        x = g.reindex(columns=cols).fillna(0.0).to_numpy("float64")
        raw = ((x - mu) / sd) @ coef
        labv = g["label"].to_numpy("float64")
        ok = np.isfinite(raw) & np.isfinite(labv)
        if ok.sum() < 40: continue
        ics.append(lab.rank_ic(raw[ok], labv[ok]))
        r = pd.Series(raw[ok]).rank(pct=True).to_numpy()
        top = r >= 0.90
        if top.any():
            exs.append(float(labv[ok][top].mean() - labv[ok].mean()))
        order = pd.Series(raw, index=g["symbol"].to_numpy()).sort_values(ascending=False)
        tops[d] = list(order.index[:8])
    ics = np.array([v for v in ics if np.isfinite(v)])
    o = newey_west_t(ics, horizon_sessions=63, step_sessions=21)
    # top-8 agreement with the correct (lag 0) selection
    if L == 0:
        base_top = tops; agree = 1.0
    else:
        ov = [len(set(tops[d]) & set(base_top.get(d, []))) / 8.0
              for d in tops if d in base_top]
        agree = float(np.mean(ov)) if ov else float("nan")
    res[L] = dict(ic=ics.mean(), icir=ics.mean()/ics.std(ddof=1), t=o.adjusted_t,
                  ex=float(np.mean(exs)), hit=float((ics > 0).mean()), agree=agree)
    print(f"{L:>4}{ics.mean():>+10.4f}{res[L]['icir']:>+8.3f}{o.adjusted_t:>+8.2f}"
          f"{np.mean(exs):>+15.2%}{res[L]['hit']:>7.0%}{agree:>19.0%}")

print()
print("lag 0 is the decision date. lag 4 is what the shipped live path uses.")
d = res[4]; b = res[0]
print(f"cost of the defect: rank IC {b['ic']:+.4f} -> {d['ic']:+.4f} "
      f"({(d['ic']/b['ic']-1):+.0%}), top-decile excess {b['ex']:+.2%} -> "
      f"{d['ex']:+.2%} per 63-session period ({(d['ex']-b['ex'])*100:+.2f}pp)")
print(f"and the shortlist itself: only {d['agree']:.0%} of the top 8 names "
      f"agree with the top 8 the same model gives on the decision date.")
