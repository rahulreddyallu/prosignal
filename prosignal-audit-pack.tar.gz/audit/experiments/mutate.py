"""Mutation probe: inject a defect, run the suite, see whether anything notices.

A test suite is evidence only insofar as a broken implementation fails it. Each
mutation below is a change that would be a serious research defect if it shipped.
"""
import subprocess, shutil, sys, re, time
from pathlib import Path

SRC = Path("/home/claude/prosignal/src/prosignal")
MUT = [
    ("purge disabled in CPCV",
     "validation/cpcv.py",
     "overlap = (candidate_train + self.label_horizon >= start) & (",
     "overlap = (candidate_train + 0 >= start) & ("),

    ("embargo disabled in CPCV",
     "validation/cpcv.py",
     "                if self.embargo > 0:",
     "                if False:"),

    ("features may read one bar into the future",
     "features/crosssec.py",
     "    hist = close.iloc[: i + 1]\n    tno = turnover.iloc[: i + 1]",
     "    hist = close.iloc[: i + 2]\n    tno = turnover.iloc[: i + 2]"),

    ("universe screen is no longer point-in-time",
     "features/crosssec.py",
     "    adtv = turnover.rolling(int(lookback_sessions), min_periods=1).median()",
     "    adtv = turnover.expanding(min_periods=1).median().iloc[-1:].reindex(\n"
     "        turnover.index, method='bfill').ffill()"),

    ("Newey-West degraded to the naive standard error",
     "features/famamacbeth.py",
     "    for lag in range(1, min(lags, t - 1) + 1):",
     "    for lag in range(1, 1):"),

    ("significance gate raised from |t|>=2 to |t|>=0 (nothing is ever killed)",
     "features/famamacbeth.py",
     "SIGNIFICANCE_FLOOR = 2.0",
     "SIGNIFICANCE_FLOOR = 0.0"),

    ("shrinkage disabled (raw Fama-MacBeth coefficients traded)",
     "features/famamacbeth.py",
     "        weight = tau2 / (tau2 + v) if (tau2 + v) > 0 else 0.0",
     "        weight = 1.0"),

    ("training no longer stops a horizon before the decision date",
     "features/crossmodel.py",
     "    train_close = hist.iloc[: len(hist) - H]",
     "    train_close = hist"),

    ("label uses the close AT the decision date (zero forward return)",
     "features/crosssec.py",
     "            fwd = close.iloc[i + horizon] / close.iloc[i] - 1.0",
     "            fwd = close.iloc[i] / close.iloc[i - 1] - 1.0"),

    ("DSR always passes",
     "validation/metrics.py",
     "    dsr = probabilistic_sharpe_ratio(arr, benchmark_sr=benchmark, observed_sr=observed)",
     "    dsr = 1.0"),

    ("costs zeroed",
     "costs.py",
     "        total = fees_total + impact_inr + spread_inr",
     "        total = 0.0 * (fees_total + impact_inr + spread_inr)"),

    ("stop distance clip removed (no bounded stop)",
     "features/exits.py",
     "        return np.clip(raw, self.min_stop_distance_pct,\n"
     "                       self.max_stop_distance_pct) / 100.0",
     "        return raw / 100.0"),
]

def run_suite(timeout=900):
    r = subprocess.run(
        [sys.executable, "-m", "pytest", "tests", "-x", "-q", "--tb=no",
         "-p", "no:cacheprovider", "--co" if False else "-q"],
        cwd="/home/claude/prosignal", capture_output=True, text=True, timeout=timeout)
    out = r.stdout + r.stderr
    failed = len([l for l in out.splitlines() if l.startswith("FAILED")])
    m = re.search(r"(\d+) failed", out)
    if m:
        failed = max(failed, int(m.group(1)))
    first = ""
    for line in out.splitlines():
        if line.startswith("FAILED"):
            first = line.split(" ")[1] if " " in line else line
            break
    return failed, first, out.strip().splitlines()[-1] if out.strip() else ""

print(f"{'mutation':<58}{'tests failed':>13}  first failure")
print("-" * 110, flush=True)
results = []
for name, rel, old, new in MUT:
    path = SRC / rel
    orig = path.read_text()
    if old not in orig:
        print(f"{name:<58}{'PATTERN NOT FOUND':>13}")
        continue
    path.write_text(orig.replace(old, new, 1))
    try:
        failed, first, last = run_suite()
    except subprocess.TimeoutExpired:
        failed, first, last = -1, "TIMEOUT", ""
    finally:
        path.write_text(orig)
    verdict = "CAUGHT" if failed > 0 else ">>> SURVIVED <<<"
    print(f"{name:<58}{failed:>13}  {verdict}  {first[:45]}", flush=True)
    results.append((name, failed, first))
print()
sur = [r for r in results if r[1] == 0]
print(f"{len(sur)} of {len(results)} injected research defects pass the suite unnoticed:")
for n, _, _ in sur:
    print("  -", n)
