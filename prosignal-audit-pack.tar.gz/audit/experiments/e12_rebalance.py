"""E12: the validated book rebalances quarterly. The live engine re-ranks every
session. What does that cost?

`portfolio_sim.simulate` advances by `stride = ceil(horizon/step)` = 3 panel
dates = 63 sessions, and holds one cohort at a time. Every book-level number in
the repository comes from that schedule. The live engine runs `analyse run`
every trading session and Stage 6 re-applies the 8/16 band each time, so a name
can be dropped days after it is bought. The recorded outcome ledger shows a
median hold of 3 sessions against a 63-session model horizon.

This is a continuous book simulator: positions are opened at a rebalance,
carried across rebalances while they stay inside the exit band, and closed by
the band or by the engine's own stop / target / invalidation, whichever comes
first. Rebalance frequency is the only thing that varies.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.features.exits import ExitRules, atr_panel, ma_panel
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sel = p[p["date"] < pd.Timestamp(store.price_sessions()[-378])].copy()
panels = pickle.loads((CACHE / "sim_panels.pkl").read_bytes())
close, low, high, open_ = panels["close"], panels["low"], panels["high"], panels["open"]
atr, ma, adtv = panels["atr"], panels["ma"], panels["adtv"]
idx = {d: i for i, d in enumerate(close.index)}
rules = ExitRules()
cm_ = CostModel(cfg)
CAP = fv(cfg.params.capital.total_capital_inr)
MAXP = iv(cfg.params.capital.max_open_positions)
RISK = fv(cfg.params.capital.risk_per_trade_pct) / 100.0
PART = fv(cfg.params.capital.max_participation_of_adtv)
ENTRY, EXITB = 8, 16

# out-of-sample rankings, one per panel date
dates = sorted(sel["date"].unique()); by_date = {d: g for d, g in sel.groupby("date")}
cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2, label_horizon=3, embargo=1)
pb = {}
for sp in cv.split(len(dates)):
    tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
    if len(tr) < 2000: continue
    fit, _f, _w = fit_coefficients(tr, features, estimator="fama_macbeth", horizon=63, step=21)
    if fit is None: continue
    for i in sp.test_idx:
        d = dates[i]; te = by_date[d]
        pb.setdefault(d, []).append(pd.Series(predict(fit, te[features].to_numpy("float64")),
                                              index=te["symbol"].to_numpy()))
rank_on = {pd.Timestamp(d): pd.concat(v, axis=1).mean(axis=1).sort_values(ascending=False)
           for d, v in pb.items()}
rdates = sorted(rank_on)
print(f"{len(rdates)} out-of-sample ranking dates, "
      f"{rdates[0].date()} .. {rdates[-1].date()}\n")


def size(sym, i, equity):
    e = close[sym].iloc[i]; a = atr[sym].iloc[i]
    if not (np.isfinite(e) and e > 0 and np.isfinite(a)): return None
    dist = min(max(rules.stop_atr_multiple * a / e * 100.0,
                   rules.min_stop_distance_pct), rules.max_stop_distance_pct) / 100.0
    liq = adtv[sym].iloc[i]
    slot = equity / MAXP
    qliq = (liq * PART) / e if np.isfinite(liq) and liq > 0 else slot / e
    qty = max(min(equity * RISK / (e * dist), slot / e, qliq), 0.0)
    return (qty, float(e), dist, float(liq) if np.isfinite(liq) else 0.0)


def resolve(sym, i0, i1, entry, dist):
    """First of stop / target / invalidation between i0+1 and i1 (inclusive)."""
    stop_lvl = entry * (1 - dist); tgt = entry * (1 + rules.target_r_multiple * dist)
    lo = low[sym].iloc[i0 + 1:i1 + 1].to_numpy()
    hi = high[sym].iloc[i0 + 1:i1 + 1].to_numpy()
    cl = close[sym].iloc[i0 + 1:i1 + 1].to_numpy()
    op = open_[sym].iloc[i0 + 1:i1 + 1].to_numpy()
    mv = ma[sym].iloc[i0 + 1:i1 + 1].to_numpy(); av = atr[sym].iloc[i0 + 1:i1 + 1].to_numpy()
    inval = cl < (mv - rules.invalidation_buffer_atr * av)
    inval = np.where(np.isfinite(mv) & np.isfinite(av) & np.isfinite(cl), inval, False)
    n = len(cl)
    if n == 0: return None
    fs = np.argmax(lo <= stop_lvl) if (lo <= stop_lvl).any() else n + 1
    ft = np.argmax(hi >= tgt) if (hi >= tgt).any() else n + 1
    fi = np.argmax(inval) if inval.any() else n + 1
    first = min(fs, ft, fi)
    if first > n: return None
    if first == fs:
        px = min(op[first], stop_lvl) if np.isfinite(op[first]) else stop_lvl
        return i0 + 1 + first, float(px), "stop"
    if first == fi: return i0 + 1 + first, float(cl[first]), "invalidation"
    return i0 + 1 + first, float(tgt), "target"


def run(every: int, band=(ENTRY, EXITB)):
    """`every` = rebalance interval in PANEL DATES (1 = 21 sessions, 3 = 63)."""
    en, ex = band
    equity = CAP
    held = {}                 # sym -> dict(i0, qty, entry, dist)
    log, trades = [], []
    sched = rdates[::every]
    for k, d in enumerate(sched):
        i = idx.get(d)
        if i is None: continue
        nxt = idx[sched[k + 1]] if k + 1 < len(sched) else min(i + 63, len(close) - 1)
        scores = rank_on[d]
        rk = {s: r for r, s in enumerate(scores.index, start=1)}
        # close anything outside the band, at this date's close
        for s in list(held):
            if rk.get(s, 10**9) > ex:
                pos = held.pop(s)
                px = close[s].iloc[i]
                if np.isfinite(px):
                    equity += pos["qty"] * (px - pos["entry"])
                    trades.append(dict(sym=s, ret=px / pos["entry"] - 1, why="band",
                                       sessions=i - pos["i0"]))
        # fill to MAXP from the entry band
        for s in list(scores.index)[:en]:
            if len(held) >= MAXP: break
            if s in held or s not in close.columns: continue
            z = size(s, i, equity)
            if z is None or z[0] <= 0: continue
            qty, e, dist, liq = z
            bps = cm_.round_trip(e, int(max(qty, 1)), adtv_inr=liq or None).total_bps_of_buy
            equity -= qty * e * bps / 10_000.0
            held[s] = dict(i0=i, qty=qty, entry=e, dist=dist)
        # carry to the next rebalance, closing anything that hits a level first
        for s in list(held):
            pos = held[s]
            r = resolve(s, max(pos["i0"], i), nxt, pos["entry"], pos["dist"])
            if r is not None and r[0] <= nxt:
                j, px, why = r
                held.pop(s)
                equity += pos["qty"] * (px - pos["entry"])
                trades.append(dict(sym=s, ret=px / pos["entry"] - 1, why=why,
                                   sessions=j - pos["i0"]))
        mtm = equity + sum(h["qty"] * (close[s].iloc[min(nxt, len(close)-1)] - h["entry"])
                           for s, h in held.items()
                           if np.isfinite(close[s].iloc[min(nxt, len(close)-1)]))
        log.append(dict(date=d, equity=mtm, n_held=len(held)))
    eq = pd.Series([r["equity"] for r in log], index=[r["date"] for r in log])
    rets = eq.pct_change().dropna()
    yrs = (eq.index[-1] - eq.index[0]).days / 365.25
    tr = pd.DataFrame(trades)
    ppy = len(rets) / yrs if yrs > 0 else np.nan
    return dict(
        every=every, rebalances=len(sched),
        total=float(eq.iloc[-1] / CAP - 1), years=yrs,
        cagr=float((eq.iloc[-1] / CAP) ** (1 / yrs) - 1) if yrs > 0 else np.nan,
        sharpe=float(rets.mean() / rets.std(ddof=1) * np.sqrt(ppy)) if rets.std(ddof=1) > 0 else np.nan,
        maxdd=float((eq / eq.cummax() - 1).min()),
        n_trades=len(tr),
        med_hold=float(tr["sessions"].median()) if len(tr) else np.nan,
        win=float((tr["ret"] > 0).mean()) if len(tr) else np.nan,
        mean_ret=float(tr["ret"].mean()) if len(tr) else np.nan,
        why=dict(tr["why"].value_counts()) if len(tr) else {})

hdr = (f"{'rebalance'.ljust(22)}{'trades':>7}{'med hold':>10}{'win':>6}"
       f"{'mean/trade':>12}{'CAGR':>8}{'Sharpe':>8}{'maxDD':>8}  exits")
print(hdr); print("-" * 108)
for every, label in ((3, "every 63 sessions"), (2, "every 42 sessions"), (1, "every 21 sessions")):
    r = run(every)
    print(f"{label:<22}{r['n_trades']:>7}{r['med_hold']:>10.0f}{r['win']:>6.0%}"
          f"{r['mean_ret']:>+12.2%}{r['cagr']:>+8.1%}{r['sharpe']:>+8.2f}{r['maxdd']:>+8.1%}"
          f"  {r['why']}", flush=True)
print()
print("band sensitivity at the 21-session rebalance:")
for band in ((8, 16), (8, 8), (8, 25), (5, 16), (8, 40)):
    r = run(1, band)
    print(f"  entry {band[0]:>2} / exit {band[1]:>2}: {r['n_trades']:>4} trades, "
          f"median hold {r['med_hold']:>3.0f}, CAGR {r['cagr']:+.1%}, Sharpe {r['sharpe']:+.2f}",
          flush=True)
