"""E6: what does each theme actually add, out of sample, at the ranking level
and at the book level?"""
import numpy as np, pandas as pd, json, pickle, time
from pathlib import Path
import lab
from prosignal.validation.harness import run_cpcv
from prosignal.validation.portfolio_sim import PortfolioParams, phase_summary
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sessions = store.price_sessions()
holdout_start = sessions[-378]
sel = p[p["date"] < pd.Timestamp(holdout_start)].copy()
print(f"selection panel {len(sel):,} rows / {sel['date'].nunique()} dates\n", flush=True)

# ---- price panels for the book simulator -------------------------------
f = CACHE / "sim_panels.pkl"
if f.exists():
    panels = pickle.loads(f.read_bytes())
else:
    m = lab.matrices()
    close = m["close"].astype("float64"); high = m["high"].astype("float64")
    low = m["low"].astype("float64"); open_ = m["open"].astype("float64")
    # volume is not stored in matrices(); reread turnover as the liquidity proxy
    keep = sorted(set(sel["symbol"]))
    close = close[[c for c in keep if c in close.columns]]
    high = high[close.columns]; low = low[close.columns]; open_ = open_[close.columns]
    prev = close.shift(1)
    tr = pd.concat([(high - low).stack(), (high - prev).abs().stack(),
                    (low - prev).abs().stack()], axis=1).max(axis=1).unstack()
    c7 = cfg.params.stage7_risk
    panels = {"close": close, "high": high, "low": low, "open": open_}
    panels["atr"] = tr.ewm(alpha=1.0 / iv(c7.atr.period_sessions), adjust=False,
                           min_periods=iv(c7.atr.period_sessions)).mean()
    panels["ma"] = close.rolling(iv(c7.thesis_invalidation.structure_ma_sessions)).mean()
    panels["adtv"] = m["turnover"].astype("float64")[close.columns].rolling(21).mean()
    f.write_bytes(pickle.dumps(panels, protocol=4))
print("sim panels ready", panels["close"].shape, flush=True)

model = CostModel(cfg)
def cost_bps(price, quantity, adtv):
    if price <= 0 or quantity <= 0: return 0.0
    return float(model.round_trip(price, int(max(quantity, 1)),
                                  adtv_inr=adtv if adtv > 0 else None).total_bps_of_buy)
cap, c6, c7 = cfg.params.capital, cfg.params.stage6_entry, cfg.params.stage7_risk
def make_params(**kw):
    base = dict(cost_fn=cost_bps, capital=fv(cap.total_capital_inr),
        max_positions=iv(cap.max_open_positions),
        risk_per_trade_pct=fv(cap.risk_per_trade_pct),
        max_participation_of_adtv=fv(cap.max_participation_of_adtv),
        stop_atr_multiple=fv(c7.stop_loss.atr_multiple),
        min_stop_distance_pct=fv(c7.stop_loss.min_stop_distance_pct),
        max_stop_distance_pct=fv(c7.stop_loss.max_stop_distance_pct),
        invalidation_ma_sessions=iv(c7.thesis_invalidation.structure_ma_sessions),
        invalidation_buffer_atr=fv(c7.thesis_invalidation.structure_buffer_atr),
        horizon_sessions=63, entry_rank=iv(c6.admission.entry_rank),
        exit_rank=iv(c6.admission.exit_rank))
    base.update(kw)
    return PortfolioParams(**base)

# ---- configurations ----------------------------------------------------
CONF = {"ALL 7 (shipped)": features}
for fcol in features:
    CONF[f"{fcol[:-2]} alone"] = [fcol]
for fcol in features:
    CONF[f"drop {fcol[:-2]}"] = [c for c in features if c != fcol]
CONF["mom+delivery (analytic gate)"] = ["mom_f", "delivery_f"]
CONF["mom+delivery+lottery (shipped gate)"] = ["mom_f", "delivery_f", "lottery_f"]

cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2,
                           label_horizon=int(np.ceil(63/21)), embargo=1)
dates = sorted(sel["date"].unique())
by_date = {d: g for d, g in sel.groupby("date")}
splits = list(cv.split(len(dates)))
print(f"{len(splits)} splits\n", flush=True)

hdr = (f"{'configuration':<38}{'IC':>9}{'excess':>9}{'ex t':>7}"
       f"{'book ret':>10}{'Sharpe':>8}{'gross':>8}{'cost':>8}{'names':>7}{'new':>6}")
print(hdr); print("-" * len(hdr), flush=True)
from prosignal.validation.significance import newey_west_t
rows = []
for name, cols in CONF.items():
    ics, exs = [], []
    per_date_pred = {}
    ok_splits = 0
    for sp in splits:
        tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
        if len(tr) < 2000: continue
        fit, _fm, _w = fit_coefficients(tr, cols, estimator="fama_macbeth",
                                        horizon=63, step=21)
        if fit is None: continue
        ok_splits += 1
        for i in sp.test_idx:
            d = dates[i]; te = by_date[d]
            pr = predict(fit, te[cols].to_numpy("float64"))
            labv = te["label"].to_numpy("float64")
            m_ok = np.isfinite(pr) & np.isfinite(labv)
            if m_ok.sum() < 40: continue
            ics.append(lab.rank_ic(pr[m_ok], te["label_rank"].to_numpy("float64")[m_ok]))
            r = pd.Series(pr[m_ok]).rank(pct=True).to_numpy()
            top = r >= 0.90
            if top.any():
                exs.append(float(labv[m_ok][top].mean() - labv[m_ok].mean()))
            per_date_pred.setdefault(d, []).append(
                pd.Series(pr, index=te["symbol"].to_numpy()))
    if not exs:
        print(f"{name:<38}  refused by the estimator on every split")
        continue
    # one ranking per date = mean of the out-of-sample predictions for it
    rankings = [(pd.Timestamp(d), pd.concat(v, axis=1).mean(axis=1).sort_values(ascending=False))
                for d, v in sorted(per_date_pred.items())]
    bm = phase_summary(rankings, panels, make_params(), step_sessions=21)
    exa = np.asarray(exs); ica = np.asarray([v for v in ics if np.isfinite(v)])
    # excess t on DISTINCT-date means, overlap-corrected
    bydate = pd.Series(exs, index=[d for d, v in sorted(per_date_pred.items())
                                   for _ in range(0)]) if False else None
    t_ex = newey_west_t(exa, horizon_sessions=63, step_sessions=21).adjusted_t
    print(f"{name:<38}{ica.mean():>+9.4f}{exa.mean():>+9.2%}{t_ex:>+7.2f}"
          f"{bm.get('mean_return', float('nan')):>+10.2%}{bm.get('sharpe', float('nan')):>+8.2f}"
          f"{bm.get('mean_gross', float('nan')):>+8.2%}{bm.get('mean_cost', float('nan')):>8.2%}"
          f"{bm.get('avg_names', float('nan')):>7.1f}{bm.get('avg_new', float('nan')):>6.1f}",
          flush=True)
    rows.append(dict(config=name, ic=ica.mean(), excess=exa.mean(), t=t_ex,
                     **{k: bm.get(k) for k in ("mean_return","sharpe","mean_gross",
                                               "mean_cost","avg_names","avg_new",
                                               "max_drawdown","hit_rate","n_periods")}))
pd.DataFrame(rows).to_csv("/home/claude/work/cache/ablation.csv", index=False)
print("\nsaved")
