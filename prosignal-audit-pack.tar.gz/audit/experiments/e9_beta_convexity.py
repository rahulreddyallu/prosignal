"""E9: why does `beta` rank badly and trade well?

Hypothesis: the training target is the raw 63-session forward return, which
charges a high-volatility name for a drawdown the book's 2.5xATR stop never
takes, and gives it no credit for the 3R target the book does take. If so, the
ranking target and the book's payoff disagree by construction on exactly the
volatility axis -- and the last commit removed the path-dependent label that
had closed that gap.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.features.exits import ExitRules, resolve_exits, atr_panel, ma_panel

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
cfg, store = lab.context()
m = lab.matrices()
close = m["close"].astype("float64"); high = m["high"].astype("float64")
low = m["low"].astype("float64"); open_ = m["open"].astype("float64")
keep = sorted(set(p["symbol"]) & set(close.columns))
close = close[keep]; high = high[keep]; low = low[keep]; open_ = open_[keep]
rules = ExitRules()   # shipped defaults: 2.5 ATR stop, 3.0R target, 50/1.5 inval, H=63
atr = atr_panel(high, low, close, rules.atr_period_sessions, rules.atr_method)
ma = ma_panel(close, rules.invalidation_ma_sessions)
idx = {d: i for i, d in enumerate(close.index)}
print("resolving book outcomes for every panel row ...", flush=True)

rows = []
for d, g in p.groupby("date"):
    if d not in idx: continue
    i = idx[d]
    if i + 63 >= len(close): continue
    out = resolve_exits(close, i, rules, high=high, low=low, open_=open_, atr=atr, ma=ma)
    sub = g.set_index("symbol")
    j = sub.index.intersection(out.index)
    rows.append(pd.DataFrame({
        "date": d, "symbol": j,
        "label": sub.loc[j, "label"].to_numpy(),
        "book_ret": out.loc[j, "ret"].to_numpy(),
        "side": out.loc[j, "side"].to_numpy(),
        "beta_f": sub.loc[j, "beta_f"].to_numpy(),
        "lottery_f": sub.loc[j, "lottery_f"].to_numpy(),
        "mom_f": sub.loc[j, "mom_f"].to_numpy(),
        "delivery_f": sub.loc[j, "delivery_f"].to_numpy(),
        "drawdown_f": sub.loc[j, "drawdown_f"].to_numpy(),
    }))
allr = pd.concat(rows, ignore_index=True).dropna(subset=["label", "book_ret"])
print(f"{len(allr):,} rows over {allr['date'].nunique()} dates\n")

print("side distribution of the book outcome:")
names = {-2.0: "invalidation", -1.0: "stop", 0.0: "timeout", 1.0: "target"}
print(allr["side"].map(names).value_counts(normalize=True).to_string())
print()

hdr = f"{'factor':<12}{'decile':>8}{'raw label':>12}{'book ret':>11}{'stop%':>8}{'target%':>9}"
print(hdr); print("-"*len(hdr))
for fac in ("beta_f", "lottery_f", "mom_f", "delivery_f", "drawdown_f"):
    allr["_d"] = allr.groupby("date")[fac].transform(
        lambda s: pd.qcut(s.rank(method="first"), 10, labels=False, duplicates="drop"))
    for dec in (0, 9):
        sub = allr[allr["_d"] == dec]
        print(f"{fac:<12}{('bottom' if dec==0 else 'top'):>8}"
              f"{sub['label'].mean():>+12.2%}{sub['book_ret'].mean():>+11.2%}"
              f"{(sub['side']==-1).mean():>8.0%}{(sub['side']==1).mean():>9.0%}")
    top = allr[allr["_d"] == 9]; bot = allr[allr["_d"] == 0]
    print(f"{'':12}{'top-bot':>8}{top['label'].mean()-bot['label'].mean():>+12.2%}"
          f"{top['book_ret'].mean()-bot['book_ret'].mean():>+11.2%}")
    print()

print("correlation between the two targets, within date:")
c = allr.groupby("date").apply(
    lambda g: np.corrcoef(g["label"].rank(), g["book_ret"].rank())[0, 1],
    include_groups=False)
print(f"  mean rank correlation label vs book outcome: {c.mean():.3f} "
      f"(min {c.min():.3f}, max {c.max():.3f})")
allr.to_parquet(CACHE / "book_outcomes.parquet")
