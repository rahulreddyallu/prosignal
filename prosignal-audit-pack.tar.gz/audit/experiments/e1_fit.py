import lab, pandas as pd, numpy as np, json, pickle
from prosignal.features import crossmodel as cm
from prosignal.features.famamacbeth import fama_macbeth, gated_shrink
from pathlib import Path

CACHE = Path("/home/claude/work/cache")
p = lab.panel_fast(tag='prod')
print("panel:", len(p), "rows,", p['date'].nunique(), "dates,",
      p['date'].min().date(), "->", p['date'].max().date(), flush=True)

f = CACHE / "panel_prepared.parquet"
if f.exists():
    p3 = pd.read_parquet(f)
    features = json.loads((CACHE / "features.json").read_text())
    dropped = {}
else:
    cfg, store = lab.context()
    m = lab.matrices()
    close = m['close'].astype('float64')
    p2 = cm._attach_fundamentals(p, store.read_statements(), close, 450,
                                 actions=store.read_corporate_actions())
    p3, features, dropped = cm.prepare_features(p2)
    p3 = p3.dropna(subset=[c for c in features if c in p3.columns] + ["label_rank"])
    p3.to_parquet(f)
    (CACHE / "features.json").write_text(json.dumps(features))
print("features fitted:", features, flush=True)
print("rows after dropna:", len(p3), flush=True)

prod = p3[p3['date'] <= '2026-02-11']
print("production-equivalent rows:", len(prod), "dates:", prod['date'].nunique(),
      "train_end:", prod['date'].max().date(), flush=True)

fm = fama_macbeth(prod, features, target='label_rank', horizon=63, step=21)
live = json.load(open('/home/claude/work/data/curated/crosssec_model.json'))
print()
print(f"{'theme':<12}{'lambda':>10}{'se(NW2)':>10}{'t':>8}   | live blob")
for c in features:
    lt = live['fm_t_stat'].get(c, float('nan')); ll = live['fm_lambda'].get(c, float('nan'))
    print(f"{c:<12}{fm.lam[c]:>+10.4f}{fm.se[c]:>10.4f}{fm.t_stat[c]:>+8.2f}   | lam {ll:+.4f} t {lt:+.2f}")
print("n_dates:", fm.n_dates, " live:", live['fm_n_dates'], " nw_lags:", fm.nw_lags)
lam = gated_shrink(fm, floor=2.0, toward='zero')
print()
print("gated+shrunk coefficients:")
for c in features:
    print(f"  {c:<12}{lam[c]:+.6f}   | live coef {live['coef'][c]:+.6f}")
fm.slopes.to_parquet(CACHE / "fm_slopes.parquet")
print("\nslopes saved")
