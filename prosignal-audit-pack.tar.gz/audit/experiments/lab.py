"""Shared research harness for the ProSignal audit.

Loads the real curated store exactly as stage4 does, and exposes the price
matrices plus a cached factor panel so experiments do not rebuild it.
"""
from __future__ import annotations
import os, sys, pickle, datetime as dt
from pathlib import Path
os.environ.setdefault("PROSIGNAL_HOME", "/home/claude/run")
import numpy as np, pandas as pd

from prosignal.config.loader import load_config
from prosignal.data.store import DataStore
from prosignal.core.paths import ProjectPaths, find_project_root

CACHE = Path("/home/claude/work/cache")
CACHE.mkdir(parents=True, exist_ok=True)


def context():
    cfg = load_config()
    root = find_project_root()
    pp = ProjectPaths(root, cfg.runtime.paths)
    store = DataStore(pp.curated, pp.snapshots)
    return cfg, store


def matrices(force: bool = False):
    """close/high/low/open/turnover/delivery pivots over the whole store."""
    f = CACHE / "matrices.pkl"
    if f.exists() and not force:
        return pickle.loads(f.read_bytes())
    cfg, store = context()
    sessions = store.price_sessions()
    px = store.read_prices(symbols=None, start=sessions[0], end=sessions[-1],
                           columns=["date", "symbol", "close", "turnover",
                                    "high", "low", "open"])
    px["date"] = pd.to_datetime(px["date"]).dt.normalize()
    out = {}
    for col in ("close", "turnover", "high", "low", "open"):
        out[col] = px.pivot_table(index="date", columns="symbol", values=col,
                                  aggfunc="last", observed=True).sort_index().astype("float32")
    del px
    dl = store.read_delivery(symbols=None, start=sessions[0], end=sessions[-1])
    dl["date"] = pd.to_datetime(dl["date"]).dt.normalize()
    out["delivery"] = dl.pivot_table(index="date", columns="symbol",
                                     values="deliv_pct", aggfunc="last",
                                     observed=True).sort_index().astype("float32")
    sec = store.read_sector_map()
    out["sectors"] = dict(zip(sec["symbol"], sec["sector"]))
    f.write_bytes(pickle.dumps(out, protocol=4))
    return out


def eligible_mask(close, turnover, cfg):
    from prosignal.features.crosssec import liquidity_mask
    u = cfg.universe
    from prosignal.stages._cfg import fv, iv
    return liquidity_mask(
        close, turnover,
        min_adtv_inr=float(fv(u.pit_min_adtv_inr)),
        lookback_sessions=int(iv(u.pit_adtv_lookback_sessions)),
        max_names=int(iv(u.pit_max_names)),
        min_history_sessions=int(iv(u.min_history_sessions)),
        min_price_inr=float(fv(u.min_price_inr)),
    )


def panel(force: bool = False, tag: str = "prod", **kw):
    """The production training panel: forward-return label, PIT eligibility,
    sector-neutral ranks."""
    f = CACHE / f"panel_{tag}.parquet"
    if f.exists() and not force:
        return pd.read_parquet(f)
    from prosignal.features.crosssec import build_panel
    cfg, store = context()
    m = matrices()
    close, turnover = m["close"].astype("float64"), m["turnover"].astype("float64")
    elig = eligible_mask(close, turnover, cfg)
    p = build_panel(close, turnover, horizon=kw.pop("horizon", 63),
                    step=kw.pop("step", 21),
                    delivery=m["delivery"].astype("float64"),
                    eligible=elig, sectors=m["sectors"], **kw)
    p.to_parquet(f)
    return p


def rank_ic(a, b):
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 8:
        return np.nan
    x = pd.Series(a[ok]).rank().to_numpy()
    y = pd.Series(b[ok]).rank().to_numpy()
    if x.std() == 0 or y.std() == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def nw_se(series, lags):
    from prosignal.features.famamacbeth import newey_west_se
    return newey_west_se(np.asarray(series, dtype="float64"), lags)


def panel_fast(force: bool = False, tag: str = "prod", horizon: int = 63,
               step: int = 21, sector_neutral: bool = True,
               exit_rules=None, restrict_eligible: bool = True,
               eligible_override=None, **kw):
    """Same panel, restricted to columns the screen ever admits.

    Equivalent by construction: build_panel discards non-eligible rows and the
    benchmark is close.where(eligible), so a column never eligible on any date
    contributes to nothing.
    """
    import time
    f = CACHE / f"panel_{tag}.parquet"
    if f.exists() and not force:
        return pd.read_parquet(f)
    from prosignal.features import crosssec as cs
    cfg, store = context()
    m = matrices()
    close = m["close"].astype("float64")
    turnover = m["turnover"].astype("float64")
    elig = (eligible_override if eligible_override is not None
            else eligible_mask(close, turnover, cfg))
    hi = lo = op = None
    if restrict_eligible:
        k = elig.any(axis=0)
        keep = k[k].index
        close = close[keep]; turnover = turnover[keep]; elig = elig[keep]
        deliv = m["delivery"].astype("float64").reindex(columns=keep)
        if exit_rules is not None:
            hi = m["high"].astype("float64")[keep]
            lo = m["low"].astype("float64")[keep]
            op = m["open"].astype("float64")[keep]
    else:
        deliv = m["delivery"].astype("float64")
    print("columns kept: %d of %d" % (close.shape[1], m["close"].shape[1]), flush=True)
    t0 = time.time()
    p = cs.build_panel(close, turnover, horizon=horizon, step=step,
                       delivery=deliv, eligible=elig,
                       sectors=(m["sectors"] if sector_neutral else None),
                       exit_rules=exit_rules, high=hi, low=lo, open_=op, **kw)
    print("panel built in %.0fs: %d rows, %d dates" % (
        time.time() - t0, len(p), p["date"].nunique()), flush=True)
    p.to_parquet(f)
    return p
