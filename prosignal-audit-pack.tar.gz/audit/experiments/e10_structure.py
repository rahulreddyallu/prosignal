"""E10: factor structure, plus the ablation redone WITHOUT the significance gate.

A gated estimator refuses a single-theme arm on the splits where that theme is
weak, so a single-theme row is scored on a SELECTED subset of splits and is not
comparable with a multi-theme row. `configuration_matrix` documents exactly this
trap for PBO; the ablation walks into it. Redone with floor=0.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.validation.portfolio_sim import PortfolioParams, simulate
from prosignal.features.crossmodel import fit_coefficients, FAMILIES
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.validation.significance import newey_west_t
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sessions = store.price_sessions()
sel = p[p["date"] < pd.Timestamp(sessions[-378])].copy()

# ---------------- structure ---------------------------------------------
print("=== within-date rank correlation of the FAMILY columns (shipped model) ===")
def wd_corr(frame, cols):
    acc = []
    for _, g in frame.groupby("date"):
        acc.append(g[cols].rank().corr(method="pearson").to_numpy())
    return pd.DataFrame(np.nanmean(acc, axis=0), index=cols, columns=cols)
C = wd_corr(sel, features)
print(C.round(3).to_string())
print()
ev = np.linalg.eigvalsh(C.to_numpy())[::-1]
ev = ev[ev > 0]
print(f"eigenvalues: {np.round(ev,3)}")
print(f"PC1 explains {ev[0]/ev.sum():.1%};  components for 90% of variance: "
      f"{int(np.searchsorted(np.cumsum(ev)/ev.sum(), 0.90) + 1)} of {len(features)}")
print(f"participation ratio (effective independent bets): "
      f"{(ev.sum()**2)/ (ev**2).sum():.2f}")
print()

print("=== within-date rank correlation of the 14 MEMBER factors ===")
mem = [c for c in sel.columns if c.endswith("_r") and c[:-2] in
       [x for fam in FAMILIES.values() for x in [y[:-2] for y in fam]]]
mem = sorted(set(mem))
Cm = wd_corr(sel, mem)
hi = [(a, b, Cm.loc[a, b]) for i, a in enumerate(mem) for b in mem[i+1:]
      if abs(Cm.loc[a, b]) >= 0.55]
for a, b, v in sorted(hi, key=lambda t: -abs(t[2])):
    print(f"  {a[:-2]:<16} {b[:-2]:<16} {v:+.3f}")
evm = np.linalg.eigvalsh(Cm.to_numpy())[::-1]; evm = evm[evm > 0]
print(f"  {len(mem)} members span {int(np.searchsorted(np.cumsum(evm)/evm.sum(), 0.90)+1)} "
      f"components for 90% of variance; participation ratio "
      f"{(evm.sum()**2)/(evm**2).sum():.2f}")
print()

# ---------------- ungated ablation --------------------------------------
panels = pickle.loads((CACHE / "sim_panels.pkl").read_bytes())
model = CostModel(cfg)
def cost_bps(price, q, adtv):
    if price <= 0 or q <= 0: return 0.0
    return float(model.round_trip(price, int(max(q, 1)), adtv_inr=adtv if adtv > 0 else None).total_bps_of_buy)
cap, c6, c7 = cfg.params.capital, cfg.params.stage6_entry, cfg.params.stage7_risk
P = PortfolioParams(cost_fn=cost_bps, capital=fv(cap.total_capital_inr),
    max_positions=iv(cap.max_open_positions), risk_per_trade_pct=fv(cap.risk_per_trade_pct),
    max_participation_of_adtv=fv(cap.max_participation_of_adtv),
    stop_atr_multiple=fv(c7.stop_loss.atr_multiple),
    min_stop_distance_pct=fv(c7.stop_loss.min_stop_distance_pct),
    max_stop_distance_pct=fv(c7.stop_loss.max_stop_distance_pct),
    invalidation_ma_sessions=iv(c7.thesis_invalidation.structure_ma_sessions),
    invalidation_buffer_atr=fv(c7.thesis_invalidation.structure_buffer_atr),
    horizon_sessions=63, entry_rank=iv(c6.admission.entry_rank),
    exit_rank=iv(c6.admission.exit_rank))
dates = sorted(sel["date"].unique()); by_date = {d: g for d, g in sel.groupby("date")}
cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2, label_horizon=3, embargo=1)
splits = list(cv.split(len(dates)))

def arm(cols, floor):
    pb, exc, ics, used = {}, {}, {}, 0
    for sp in splits:
        tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
        if len(tr) < 2000: continue
        fit, _f, _w = fit_coefficients(tr, cols, estimator="fama_macbeth",
                                       horizon=63, step=21, significance_floor=floor)
        if fit is None: continue
        used += 1
        for i in sp.test_idx:
            d = dates[i]; te = by_date[d]
            pr = predict(fit, te[cols].to_numpy("float64"))
            lb = te["label"].to_numpy("float64")
            ok = np.isfinite(pr) & np.isfinite(lb)
            if ok.sum() < 40: continue
            r = pd.Series(pr[ok]).rank(pct=True).to_numpy(); top = r >= 0.90
            if top.any(): exc.setdefault(d, []).append(float(lb[ok][top].mean()-lb[ok].mean()))
            ics.setdefault(d, []).append(lab.rank_ic(pr[ok], te["label_rank"].to_numpy("float64")[ok]))
            pb.setdefault(d, []).append(pd.Series(pr, index=te["symbol"].to_numpy()))
    if not exc: return None
    ds = pd.Series({d: float(np.mean(v)) for d, v in exc.items()}).sort_index()
    ic = float(np.nanmean([np.nanmean(v) for v in ics.values()]))
    rk = [(pd.Timestamp(d), pd.concat(v, axis=1).mean(axis=1).sort_values(ascending=False))
          for d, v in sorted(pb.items())]
    per = pd.concat([simulate(rk, panels, P, phase=ph, step_sessions=21).periods
                     for ph in range(3)], ignore_index=True)
    sd = per["ret"].std(ddof=1)
    return dict(used=used, ic=ic, ex=ds.mean(),
                t=newey_west_t(ds.to_numpy(), horizon_sessions=63, step_sessions=21).adjusted_t,
                net=per["ret"].mean(), sr=per["ret"].mean()/sd*2.0 if sd > 0 else np.nan,
                dep=per["deployed_frac"].mean(), ndates=len(ds))

print("=== single-theme arms, gate OFF (floor=0) -- every split contributes ===")
hdr = f"{'theme':<14}{'splits':>7}{'dates':>7}{'IC':>9}{'excess':>9}{'t':>7}{'net':>9}{'SR':>7}{'dep':>6}"
print(hdr); print("-"*len(hdr), flush=True)
for c in features + ["ALL7", "MOM+DEL"]:
    cols = features if c == "ALL7" else (["mom_f", "delivery_f"] if c == "MOM+DEL" else [c])
    r = arm(cols, 0.0)
    if r is None: print(f"{c:<14} refused"); continue
    print(f"{c:<14}{r['used']:>7}{r['ndates']:>7}{r['ic']:>+9.4f}{r['ex']:>+9.2%}"
          f"{r['t']:>+7.2f}{r['net']:>+9.2%}{r['sr']:>+7.2f}{r['dep']:>6.0%}", flush=True)
