"""E2: is the significance gate using the correction the repo itself prefers?"""
import numpy as np, pandas as pd, json
from pathlib import Path
from prosignal.features.famamacbeth import newey_west_se
from prosignal.validation.significance import analytic_vif, newey_west_t

CACHE = Path("/home/claude/work/cache")
slopes = pd.read_parquet(CACHE / "fm_slopes.parquet")
n = len(slopes)
print(f"slope series: {n} cross-sections\n")

av = analytic_vif(63, 21, n)
print(f"analytic VIF for h=63, s=21, n={n}: {av:.4f}  (sqrt = {np.sqrt(av):.4f})")
print()
hdr = f"{'theme':<12}{'lambda':>10}{'naive t':>9}{'NW2 t':>9}{'estVIF':>8}{'analytic t':>12}{'gate@2':>9}"
print(hdr); print("-"*len(hdr))
rows = []
for c in slopes.columns:
    s = slopes[c].to_numpy("float64")
    mean = float(np.nanmean(s))
    naive_se = float(np.nanstd(s, ddof=1) / np.sqrt(n))
    nw = newey_west_se(s, 2)
    o = newey_west_t(s, horizon_sessions=63, step_sessions=21, use_analytic_vif=True)
    est_vif = (nw / naive_se) ** 2
    t_naive = mean / naive_se
    t_nw = mean / nw
    t_an = o.adjusted_t
    verdict = ("keep" if abs(t_nw) >= 2 else "kill") + " -> " + ("keep" if abs(t_an) >= 2 else "KILL")
    print(f"{c:<12}{mean:>+10.4f}{t_naive:>+9.2f}{t_nw:>+9.2f}{est_vif:>8.2f}{t_an:>+12.2f}   {verdict}")
    rows.append(dict(theme=c, lam=mean, t_naive=t_naive, t_nw=t_nw,
                     est_vif=est_vif, t_analytic=t_an))
print()
print("The engine's gate uses the NW2 column. significance.py argues the")
print("analytic column is the right one and is used for every REPORTED figure.")
print()
# what changes
df = pd.DataFrame(rows)
kept_nw = set(df[df.t_nw.abs() >= 2].theme)
kept_an = set(df[df.t_analytic.abs() >= 2].theme)
print("themes priced under the shipped gate :", sorted(kept_nw))
print("themes priced under the analytic gate:", sorted(kept_an))
print("difference                           :", sorted(kept_nw ^ kept_an))
