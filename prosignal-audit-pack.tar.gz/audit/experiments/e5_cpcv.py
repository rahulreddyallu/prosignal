"""E5: run the engine's own CPCV, then take its Deflated Sharpe apart."""
import numpy as np, pandas as pd, json, time
from pathlib import Path
import lab
from prosignal.validation.harness import run_cpcv
from prosignal.validation.metrics import (deflated_sharpe_ratio, sharpe_ratio,
                                          expected_max_sharpe, probabilistic_sharpe_ratio)

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sessions = store.price_sessions()
holdout_start = sessions[-378]
print("holdout starts", holdout_start)
sel = p[p["date"] < pd.Timestamp(holdout_start)]
print(f"selection-period panel: {len(sel):,} rows / {sel['date'].nunique()} dates "
      f"({sel['date'].min().date()} -> {sel['date'].max().date()})\n")

t0 = time.time()
res = run_cpcv(sel, features, horizon_sessions=63, step_sessions=21,
               alpha=20000.0, n_groups=10, n_test_groups=2,
               purge_sessions=63, embargo_sessions=21,
               estimator="fama_macbeth",
               progress=lambda n, t: print(f"  split {n}/{t}", flush=True) if n % 15 == 0 else None)
print(f"cpcv in {time.time()-t0:.0f}s\n")

ex = np.asarray(res.excess, dtype="float64"); ex = ex[np.isfinite(ex)]
ics = np.asarray(res.ic, dtype="float64"); ics = ics[np.isfinite(ics)]
sp = res.path_spread()
n_unique_dates = sel["date"].nunique()

print(f"splits fitted        {res.n_splits}")
print(f"paths woven          {len(res.path_sharpes)} of {res.n_paths}")
print(f"pooled rank IC       {res.mean_ic:+.4f}   (n={ics.size})")
print(f"pooled excess        {ex.mean():+.4%} per 63-session period, "
      f"over {ex.size:,} 'scored test dates'")
print(f"  ... but only {n_unique_dates} DISTINCT dates exist in the panel, so each "
      f"appears about {ex.size/n_unique_dates:.0f} times")
print(f"path Sharpe          min {sp.get('min'):+.2f}  median {sp.get('median'):+.2f} "
      f" max {sp.get('max'):+.2f}  sd {sp.get('sd'):.2f}  negative {sp.get('share_negative'):.0%}")
print()

trials = 44
print("=== the Deflated Sharpe, as the engine computes it ===")
d = deflated_sharpe_ratio(list(ex), n_trials=trials)
print(f"  observed per-period SR      {d.observed_sr:+.4f}")
print(f"  n treated as independent    {d.n_observations:,}")
print(f"  sr_variance fallback used   {1.0/max(d.n_observations-1,1):.3e}   "
      f"(docstring says 'conservative unit variance'; the code is 1/(n-1))")
print(f"  benchmark (expected max SR) {d.benchmark_sr:+.4f}")
print(f"  DSR                         {d.deflated_sr:.4f}   {'PASS' if d.passes else 'FAIL'}")
print()

print("=== the same arithmetic with each assumption repaired ===")
def dsr_manual(vals, n_eff, sr_var, n_trials):
    sr = sharpe_ratio(vals)
    c = np.asarray(vals) - np.mean(vals)
    sd = np.std(vals, ddof=1)
    skew = float((c**3).mean()/sd**3); kurt = float((c**4).mean()/sd**4)
    bench = expected_max_sharpe(n_trials, sr_var)
    den = 1.0 - skew*sr + ((kurt-1.0)/4.0)*sr*sr
    if den <= 0: return sr, bench, 0.0
    from prosignal.validation.metrics import norm_cdf
    return sr, bench, norm_cdf((sr - bench)*np.sqrt(max(n_eff-1,1))/np.sqrt(den))

# collapse duplicates: mean excess per distinct date
by_date = {}
# rebuild per-date means from paths
rowsd = []
for pid, _ in enumerate([]):
    pass
# recompute: pool excess by test date using the same loop the harness used is not
# exposed, so approximate with the path structure
uniq = ex.size / n_unique_dates
variants = [
    ("as shipped: n = pooled (split,date) pairs, sr_var = 1/(n-1)",
     ex.size, 1.0/max(ex.size-1, 1)),
    ("n = distinct panel dates (each date counted once)",
     n_unique_dates, 1.0/max(n_unique_dates-1, 1)),
    ("n = independent 63-session windows (dates / 3)",
     max(int(n_unique_dates/3), 3), 1.0/max(int(n_unique_dates/3)-1, 1)),
    ("as shipped n, but sr_var = 1.0 as the docstring claims",
     ex.size, 1.0),
    ("n = independent windows AND sr_var from the path Sharpes",
     max(int(n_unique_dates/3), 3),
     float(np.var(np.asarray(res.path_sharpes), ddof=1)) if len(res.path_sharpes) > 1 else 1.0),
]
print(f"  {'variant':<58}{'bench':>8}{'DSR':>9}")
for name, n_eff, sv in variants:
    sr, bench, val = dsr_manual(ex, n_eff, sv, trials)
    print(f"  {name:<58}{bench:>+8.3f}{val:>9.4f}")
print()
print(f"  observed per-period Sharpe of the pooled excess series: {sharpe_ratio(ex):+.4f}")
print(f"  path-Sharpe variance across the {len(res.path_sharpes)} woven paths: "
      f"{np.var(np.asarray(res.path_sharpes), ddof=1):.5f}")

np.save("/home/claude/work/cache/cpcv_excess.npy", ex)
np.save("/home/claude/work/cache/cpcv_paths.npy", np.asarray(res.path_sharpes))
for n in res.notes[:6]:
    print("  note:", n)
