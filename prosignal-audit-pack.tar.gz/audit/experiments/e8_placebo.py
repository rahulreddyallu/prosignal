"""E8: the null test the engine never ran.

If a RANDOM ranking, or a deliberately INVERTED one, also produces a positive
book Sharpe through this simulator, then book-level Sharpe is not evidence
about the ranking -- it is evidence about the risk overlay. Every Stage 6/7/8
comparison in the repository is decided on book Sharpe.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.validation.portfolio_sim import PortfolioParams, simulate
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sessions = store.price_sessions()
sel = p[p["date"] < pd.Timestamp(sessions[-378])].copy()
panels = pickle.loads((CACHE / "sim_panels.pkl").read_bytes())
model = CostModel(cfg)
def cost_bps(price, q, adtv):
    if price <= 0 or q <= 0: return 0.0
    return float(model.round_trip(price, int(max(q, 1)), adtv_inr=adtv if adtv > 0 else None).total_bps_of_buy)
cap, c6, c7 = cfg.params.capital, cfg.params.stage6_entry, cfg.params.stage7_risk
P = PortfolioParams(
    cost_fn=cost_bps, capital=fv(cap.total_capital_inr),
    max_positions=iv(cap.max_open_positions), risk_per_trade_pct=fv(cap.risk_per_trade_pct),
    max_participation_of_adtv=fv(cap.max_participation_of_adtv),
    stop_atr_multiple=fv(c7.stop_loss.atr_multiple),
    min_stop_distance_pct=fv(c7.stop_loss.min_stop_distance_pct),
    max_stop_distance_pct=fv(c7.stop_loss.max_stop_distance_pct),
    invalidation_ma_sessions=iv(c7.thesis_invalidation.structure_ma_sessions),
    invalidation_buffer_atr=fv(c7.thesis_invalidation.structure_buffer_atr),
    horizon_sessions=63, entry_rank=iv(c6.admission.entry_rank),
    exit_rank=iv(c6.admission.exit_rank))

dates = sorted(sel["date"].unique())
by_date = {d: g for d, g in sel.groupby("date")}
cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2, label_horizon=3, embargo=1)
splits = list(cv.split(len(dates)))

def oos_pred(cols):
    pb = {}
    for sp in splits:
        tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
        if len(tr) < 2000: continue
        fit, _f, _w = fit_coefficients(tr, cols, estimator="fama_macbeth", horizon=63, step=21)
        if fit is None: continue
        for i in sp.test_idx:
            d = dates[i]; te = by_date[d]
            pb.setdefault(d, []).append(pd.Series(predict(fit, te[cols].to_numpy("float64")),
                                                  index=te["symbol"].to_numpy()))
    return {d: pd.concat(v, axis=1).mean(axis=1) for d, v in pb.items()}

def book(rankings, tag):
    rs = [simulate(rankings, panels, P, phase=ph, step_sessions=21) for ph in range(3)]
    per = pd.concat([r.periods for r in rs if not r.empty], ignore_index=True)
    if per.empty: return None
    net = per["ret"].mean(); sd = per["ret"].std(ddof=1)
    return dict(tag=tag, net=net, gross=per["gross_ret"].mean(),
                sr=net/sd*2.0 if sd > 0 else np.nan, dep=per["deployed_frac"].mean(),
                hit=float((per["ret"] > 0).mean()), n=len(per))

def ic_of(rankmap):
    vals = []
    for d, s in rankmap.items():
        te = by_date[d]
        m = pd.Series(te["label"].to_numpy("float64"), index=te["symbol"].to_numpy())
        j = s.dropna().index.intersection(m.dropna().index)
        if len(j) < 40: continue
        vals.append(lab.rank_ic(s[j].to_numpy(), m[j].to_numpy()))
    return float(np.nanmean(vals))

mom = oos_pred(["mom_f"])
allp = oos_pred(features)
rows = []
arms = {
    "shipped 7 themes": allp,
    "momentum alone": mom,
    "INVERTED momentum": {d: -s for d, s in mom.items()},
    "INVERTED 7 themes": {d: -s for d, s in allp.items()},
}
rng = np.random.default_rng(20260827)
for k in range(5):
    arms[f"RANDOM ranking #{k+1}"] = {
        d: pd.Series(rng.standard_normal(len(s)), index=s.index) for d, s in mom.items()}
# equal-weight the whole eligible universe, for reference
hdr = f"{'arm':<24}{'rank IC':>10}{'net':>9}{'gross':>9}{'SR':>8}{'deploy':>8}{'hit':>7}{'n':>5}"
print(hdr); print("-"*len(hdr), flush=True)
for tag, rm in arms.items():
    rk = [(pd.Timestamp(d), s.sort_values(ascending=False)) for d, s in sorted(rm.items())]
    b = book(rk, tag)
    if b is None: continue
    print(f"{tag:<24}{ic_of(rm):>+10.4f}{b['net']:>+9.2%}{b['gross']:>+9.2%}"
          f"{b['sr']:>+8.2f}{b['dep']:>8.0%}{b['hit']:>7.0%}{b['n']:>5d}", flush=True)
    rows.append(b)
rnd = [r for r in rows if r["tag"].startswith("RANDOM")]
if rnd:
    srs = np.array([r["sr"] for r in rnd]); nets = np.array([r["net"] for r in rnd])
    print()
    print(f"random rankers: Sharpe mean {srs.mean():+.2f} (range {srs.min():+.2f} .. "
          f"{srs.max():+.2f}); net {nets.mean():+.2%} per 63-session period")
    print("A book built on noise, run through this simulator, is the baseline every")
    print("Stage 6/7/8 comparison in the repository should have been measured against.")
