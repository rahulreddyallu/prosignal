"""E11: does the shipped model's edge survive its own factors?

The regressors are built from the engine's own family definitions on the same
universe and the same dates, so this is a hostile test by construction. An
intercept that survives it has survived something.
"""
import numpy as np, pandas as pd, json, pickle
from pathlib import Path
import lab
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.validation.significance import newey_west_t, analytic_vif
from prosignal.validation.portfolio_sim import PortfolioParams, simulate
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

CACHE = Path("/home/claude/work/cache")
p = pd.read_parquet(CACHE / "panel_prepared.parquet")
features = json.loads((CACHE / "features.json").read_text())
cfg, store = lab.context()
sel = p[p["date"] < pd.Timestamp(store.price_sessions()[-378])].copy()
dates = sorted(sel["date"].unique()); by_date = {d: g for d, g in sel.groupby("date")}

def long_short(g, col, tail=0.30):
    s = g[col]; f = g["label"]
    ok = s.notna() & f.notna()
    s, f = s[ok], f[ok]
    if len(s) < 40: return np.nan
    r = s.rank(pct=True)
    return float(f[r >= 1 - tail].mean() - f[r <= tail].mean())

FACS = ["mom_f", "reversal_f", "lottery_f", "skew_f", "beta_f", "drawdown_f", "delivery_f"]
fac = pd.DataFrame({c: {d: long_short(g, c) for d, g in sel.groupby("date")} for c in FACS})
fac["MKT"] = {d: float(g["label"].mean()) for d, g in sel.groupby("date")}
fac = fac.sort_index()
print("long-short factor returns per 63-session period (engine's own definitions):")
print(fac.mean().round(4).to_string()); print()

# strategy: out-of-sample top-decile excess, one value per date
cv = CombinatorialPurgedCV(n_groups=10, n_test_groups=2, label_horizon=3, embargo=1)
splits = list(cv.split(len(dates)))
exc, preds = {}, {}
for sp in splits:
    tr = sel[sel["date"].isin([dates[i] for i in sp.train_idx])]
    if len(tr) < 2000: continue
    fit, _f, _w = fit_coefficients(tr, features, estimator="fama_macbeth", horizon=63, step=21)
    if fit is None: continue
    for i in sp.test_idx:
        d = dates[i]; te = by_date[d]
        pr = predict(fit, te[features].to_numpy("float64"))
        lb = te["label"].to_numpy("float64")
        ok = np.isfinite(pr) & np.isfinite(lb)
        if ok.sum() < 40: continue
        r = pd.Series(pr[ok]).rank(pct=True).to_numpy(); top = r >= 0.90
        if top.any(): exc.setdefault(d, []).append(float(lb[ok][top].mean() - lb[ok].mean()))
        preds.setdefault(d, []).append(pd.Series(pr, index=te["symbol"].to_numpy()))
strat = pd.Series({d: float(np.mean(v)) for d, v in exc.items()}).sort_index()
print(f"strategy top-decile excess: {strat.mean():+.2%} per period over {len(strat)} dates\n")

def ols(y, X, names):
    Xd = np.column_stack([np.ones(len(y))] + [X[c].to_numpy() for c in names])
    ok = np.isfinite(Xd).all(axis=1) & np.isfinite(y)
    Xd, yv = Xd[ok], np.asarray(y)[ok]
    b, *_ = np.linalg.lstsq(Xd, yv, rcond=None)
    resid = yv - Xd @ b
    n, k = Xd.shape
    if n <= k: return None
    s2 = float(resid @ resid) / (n - k)
    cov = s2 * np.linalg.pinv(Xd.T @ Xd)
    se = np.sqrt(np.diag(cov))
    tt = b / se
    ss_tot = float(((yv - yv.mean()) ** 2).sum())
    r2 = 1 - float(resid @ resid) / ss_tot if ss_tot > 0 else np.nan
    vif = analytic_vif(63, 21, n)
    return dict(b=b, t=tt, t_adj=tt / np.sqrt(vif), r2=r2, n=n, names=names, vif=vif)

SETS = [("MKT only", ["MKT"]),
        ("MOM only", ["mom_f"]),
        ("MOM + MKT", ["mom_f", "MKT"]),
        ("MOM + DELIVERY", ["mom_f", "delivery_f"]),
        ("MOM + DELIVERY + MKT", ["mom_f", "delivery_f", "MKT"]),
        ("all 7 families", FACS),
        ("all 7 + MKT", FACS + ["MKT"])]
print(f"{'factor set':<24}{'R2':>7}{'alpha/period':>14}{'naive t':>9}{'adj t':>8}{'survives t>=2':>15}")
print("-" * 78)
for nm, cols in SETS:
    r = ols(strat, fac.reindex(strat.index), cols)
    if r is None:
        print(f"{nm:<24}  too few observations"); continue
    print(f"{nm:<24}{r['r2']:>7.3f}{r['b'][0]:>+14.2%}{r['t'][0]:>+9.2f}"
          f"{r['t_adj'][0]:>+8.2f}{'yes' if r['t_adj'][0] >= 2 else 'NO':>15}")
print()
r = ols(strat, fac.reindex(strat.index), FACS)
print("loadings under the full 7-family model:")
for i, c in enumerate(FACS):
    print(f"  {c:<12}{r['b'][i+1]:>+9.3f}  t {r['t'][i+1]:>+6.2f}  (adj {r['t_adj'][i+1]:>+6.2f})")
print(f"  n = {r['n']} overlapping 63-session windows; analytic VIF {r['vif']:.2f}, "
      f"so about {r['n']/r['vif']:.0f} independent observations against "
      f"{len(FACS)+1} parameters.")
