"""E13: the book against the benchmark, by regime.

A long-only, stop-managed, 8-name book should lag a rising market and protect in
a falling one. That trade is the engine's whole economic proposition and it has
never been measured, because nothing in the repository compares the book to any
benchmark at all.
"""
import numpy as np, pandas as pd, json, pickle, datetime as dt
from pathlib import Path
import lab
from prosignal.features.crossmodel import fit_coefficients
from prosignal.features.linear import predict
from prosignal.validation.cpcv import CombinatorialPurgedCV
from prosignal.features.exits import ExitRules
from prosignal.costs import CostModel
from prosignal.stages._cfg import fv, iv

exec(open("/home/claude/run/e12_rebalance.py").read().split("hdr = (")[0])

def equity_curve(every=1, band=(8, 16)):
    en, ex = band
    equity = CAP; held = {}; log = []
    sched = rdates[::every]
    for k, d in enumerate(sched):
        i = idx.get(d)
        if i is None: continue
        nxt = idx[sched[k+1]] if k+1 < len(sched) else min(i+63, len(close)-1)
        scores = rank_on[d]; rk = {s: r for r, s in enumerate(scores.index, start=1)}
        for s in list(held):
            if rk.get(s, 10**9) > ex:
                pos = held.pop(s); px = close[s].iloc[i]
                if np.isfinite(px): equity += pos["qty"] * (px - pos["entry"])
        for s in list(scores.index)[:en]:
            if len(held) >= MAXP: break
            if s in held or s not in close.columns: continue
            z = size(s, i, equity)
            if z is None or z[0] <= 0: continue
            qty, e, dist, liq = z
            equity -= qty * e * cm_.round_trip(e, int(max(qty,1)),
                        adtv_inr=liq or None).total_bps_of_buy / 10_000.0
            held[s] = dict(i0=i, qty=qty, entry=e, dist=dist)
        for s in list(held):
            pos = held[s]
            r = resolve(s, max(pos["i0"], i), nxt, pos["entry"], pos["dist"])
            if r is not None and r[0] <= nxt:
                j, px, why = r; held.pop(s)
                equity += pos["qty"] * (px - pos["entry"])
        mtm = equity + sum(h["qty"] * (close[s].iloc[min(nxt, len(close)-1)] - h["entry"])
                           for s, h in held.items()
                           if np.isfinite(close[s].iloc[min(nxt, len(close)-1)]))
        log.append((d, mtm))
    return pd.Series([v for _, v in log], index=[d for d, _ in log]) / CAP

book = equity_curve(1)
cfg2, store2 = lab.context()
ixr = store2.read_indices(start=book.index[0].date(), end=book.index[-1].date())
n200 = ixr[ixr["index_name"] == "Nifty 200"].set_index("date")["close"].sort_index()
mom30 = ixr[ixr["index_name"] == "Nifty200 Momentum 30"].set_index("date")["close"].sort_index()
m = lab.matrices()
elig = lab.eligible_mask(m["close"].astype("float64"), m["turnover"].astype("float64"), cfg2)
cl = m["close"].astype("float64").loc[book.index[0]:book.index[-1]]
el = elig.loc[cl.index].reindex(columns=cl.columns).fillna(False)
ew = (cl.pct_change(fill_method=None).where(el.shift(1).fillna(False))
      .mean(axis=1, skipna=True).fillna(0.0) + 1).cumprod()

def at(s, d):
    s = s[s.index <= d]
    return float(s.iloc[-1]) if len(s) else np.nan

periods = [("2019-02-18", "2020-01-31", "pre-covid grind"),
           ("2020-01-31", "2020-03-31", "COVID CRASH"),
           ("2020-03-31", "2021-12-31", "rebound"),
           ("2022-01-01", "2022-12-31", "2022 drawdown"),
           ("2023-01-01", "2025-02-03", "2023-25 bull")]
print(f"{'period':<20}{'from':<12}{'to':<12}{'BOOK':>9}{'EW univ':>9}"
      f"{'Nifty200':>10}{'Mom30':>9}")
print("-" * 82)
for a, b, name in periods:
    A, B = pd.Timestamp(a), pd.Timestamp(b)
    def ret(s):
        x, y = at(s, A), at(s, B)
        return (y / x - 1) if np.isfinite(x) and np.isfinite(y) and x else np.nan
    print(f"{name:<20}{a:<12}{b:<12}{ret(book):>+9.1%}{ret(ew):>+9.1%}"
          f"{ret(n200):>+10.1%}{ret(mom30):>+9.1%}")
print()
yrs = (book.index[-1] - book.index[0]).days / 365.25
for nm, s in (("BOOK (21-session rebalance)", book), ("equal-weight universe", ew),
              ("Nifty 200", n200), ("Nifty200 Momentum 30", mom30)):
    s2 = s[(s.index >= book.index[0]) & (s.index <= book.index[-1])].dropna()
    if len(s2) < 5: continue
    tot = s2.iloc[-1] / s2.iloc[0] - 1
    print(f"  {nm:<30} total {tot:>+8.1%}   CAGR {(1+tot)**(1/yrs)-1:>+6.1%}   "
          f"maxDD {(s2/s2.cummax()-1).min():>+6.1%}")
