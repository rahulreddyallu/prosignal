"""Stage 7 -- Risk, stop, target, and position size.

Stop distance derives from the stock's own volatility rather than a flat
percent. A 5% stop is loose on an FMCG major and inside the daily noise of a
smallcap that swings 4%, so a fixed number stops out of the volatile names
where the premium sits.

Two exit levels, kept separate:

    stop_price          where the position is closed on price
    invalidation_level  where the original thesis is dead

A stock can hold above its stop while the reason for buying it has gone, which
is an exit even though the stop never fired.

Position size binds three constraints -- risk budget, capital and liquidity --
and the tightest wins. A trade whose executable size would move the price more
than the modelled edge is not a trade.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


from ..core.contracts import ExitCondition, RiskPlan
from ..core.enums import ExitReason, RiskCategory
from ..core.logging import get_logger
from ..costs import CostModel
from ._cfg import bv, fv, iv, v
from ..indicators import atr, realised_volatility
from ..liquidity import LiquidityState, assess

__all__ = ["build_plan", "STAGE_NAME"]

STAGE_NAME = "stage7_risk"
log = get_logger(__name__)


def build_plan(
    ticker: str,
    frame: pd.DataFrame,
    reference_price: float,
    composite_score: float,
    adtv_inr: Optional[float],
    config,
    costs: CostModel,
) -> RiskPlan:
    p = config.params
    cfg = p.stage7_risk
    notes: List[str] = []

    a_series = atr(
        frame["high"], frame["low"], frame["close"],
        iv(cfg.atr.period_sessions), str(v(cfg.atr.method)),
    ).dropna()
    if a_series.empty:
        return RiskPlan(ticker=ticker, reference_price=reference_price,
                        notes=["ATR not computable; no risk plan"])
    atr_value = float(a_series.iloc[-1])
    atr_pct = atr_value / reference_price * 100.0

    # ---- stop -------------------------------------------------------------
    mult = fv(cfg.stop_loss.atr_multiple)
    raw_stop = reference_price - mult * atr_value
    dist_pct = (reference_price - raw_stop) / reference_price * 100.0

    min_pct = fv(cfg.stop_loss.min_stop_distance_pct)
    max_pct = fv(cfg.stop_loss.max_stop_distance_pct)
    basis = f"{mult:g} x ATR({iv(cfg.atr.period_sessions)})"
    if dist_pct < min_pct:
        raw_stop = reference_price * (1 - min_pct / 100.0)
        dist_pct = min_pct
        basis += f", widened to the {min_pct:g}% floor"
        notes.append(
            f"ATR stop was {mult:g}x = {mult*atr_pct:.1f}%, inside the {min_pct:g}% "
            f"floor. A stop inside the stock's daily noise is a guaranteed exit."
        )
    elif dist_pct > max_pct:
        raw_stop = reference_price * (1 - max_pct / 100.0)
        dist_pct = max_pct
        basis += f", capped at the {max_pct:g}% ceiling"
        notes.append(
            f"ATR stop was {mult*atr_pct:.1f}%, beyond the {max_pct:g}% cap. Risk per "
            f"share is capped, which reduces position size rather than accepting the loss."
        )

    stop_price = _round_paise(raw_stop, p)
    risk_per_share = reference_price - stop_price

    # ---- targets ----------------------------------------------------------
    t1_r = fv(cfg.targets.t1_r_multiple)
    t2_r = fv(cfg.targets.t2_r_multiple)
    t1 = _round_paise(reference_price + t1_r * risk_per_share, p)
    t2 = _round_paise(reference_price + t2_r * risk_per_share, p)
    target_basis = f"{t1_r:g}R and {t2_r:g}R from a {dist_pct:.1f}% stop"

    resistance = _resistance(frame, iv(cfg.targets.resistance_lookback_sessions), reference_price)
    snap = fv(cfg.targets.snap_to_resistance_within_pct)
    if resistance is not None and 0 < (resistance - t1) / t1 * 100.0 <= snap:
        t1 = _round_paise(resistance * 0.995, p)
        target_basis += f"; T1 pulled below resistance at Rs {resistance:,.2f}"
        notes.append(
            f"T1 sits just under prior resistance at Rs {resistance:,.2f}. Targeting "
            f"through overhead supply is how a winning trade becomes a round trip."
        )

    rr1 = (t1 - reference_price) / risk_per_share if risk_per_share > 0 else None
    rr2 = (t2 - reference_price) / risk_per_share if risk_per_share > 0 else None

    # ---- invalidation (distinct from the stop) ----------------------------
    inval_ma = iv(cfg.thesis_invalidation.structure_ma_sessions)
    buf = fv(cfg.thesis_invalidation.structure_buffer_atr)
    closes = pd.Series(frame["close"].to_numpy(dtype="float64"))
    ma = closes.rolling(inval_ma, min_periods=inval_ma).mean()
    invalidation = None
    inval_basis = None
    if not ma.dropna().empty:
        invalidation = _round_paise(float(ma.iloc[-1]) - buf * atr_value, p)
        inval_basis = (
            f"close below the {inval_ma}-session average less {buf:g} ATR -- the "
            f"structure the entry relied on is gone, whether or not the stop fired"
        )

    # ---- risk category ----------------------------------------------------
    rel_vol = _relative_vol(frame, iv(cfg.risk_category.relative_vol_lookback_sessions))
    category = _category(composite_score, rel_vol, cfg)

    # ---- position size: risk budget vs capital vs LIQUIDITY ---------------
    qty, size_notes, size_inputs, liquidity_state = _position_size(
        reference_price, risk_per_share, adtv_inr, category, p, costs
    )
    notes.extend(size_notes)

    # Sizing rests on 21-session ADTV, which is the slowest-moving estimate
    # exactly when it matters most: liquidity leaves a name in days, not
    # months, and the trailing window keeps quoting the depth that used to be
    # there. Comparing a short window against it surfaces the divergence to the
    # operator. This never resizes or exits anything on its own -- it is a
    # statement about the plan's assumption, not an instruction.
    liquidity_ratio, liquidity_warning = _recent_liquidity(frame, adtv_inr, cfg)
    if liquidity_warning:
        notes.append(liquidity_warning)

    cb = costs.round_trip(reference_price, qty, adtv_inr=adtv_inr) if qty > 0 else None
    cost_bps = cb.total_bps_of_buy if cb else None
    impact_bps = costs.impact_bps(reference_price * qty, adtv_inr) if qty > 0 else None

    if cb and rr1:
        gross_t1_pct = (t1 - reference_price) / reference_price * 100.0
        net_t1_pct = gross_t1_pct - cb.total_bps_of_buy / 100.0
        notes.append(
            f"T1 is {gross_t1_pct:.2f}% gross, {net_t1_pct:.2f}% after "
            f"{cb.total_bps_of_buy:.0f} bps of round-trip cost."
        )

    exits = _exit_hierarchy(cfg, stop_price, invalidation, t1, t2)
    hold_lo = iv(cfg.holding_period.min_holding_sessions)
    hold_hi = iv(cfg.holding_period.max_holding_sessions)

    return RiskPlan(
        ticker=ticker,
        reference_price=reference_price,
        atr=round(atr_value, 4),
        atr_pct_of_price=round(atr_pct, 3),
        stop_price=stop_price,
        stop_distance_pct=round(dist_pct, 3),
        stop_basis=basis,
        invalidation_level=invalidation,
        invalidation_basis=inval_basis,
        trailing_stop_rule=(
            f"{str(v(cfg.trailing_stop.style))} at {fv(cfg.trailing_stop.atr_multiple):g} ATR, "
            f"active after {fv(cfg.trailing_stop.activate_after_r):g}R"
            if bv(cfg.trailing_stop.enabled) else None
        ),
        target_1=t1,
        target_2=t2,
        target_basis=target_basis,
        reward_to_risk_t1=round(rr1, 2) if rr1 else None,
        reward_to_risk_t2=round(rr2, 2) if rr2 else None,
        risk_category=category,
        risk_category_inputs={**size_inputs, "composite_score": round(composite_score, 4),
                              "relative_volatility": round(rel_vol, 3) if rel_vol else 0.0},
        position_size_shares=int(qty),
        position_value_inr=round(float(qty) * float(reference_price), 2) if qty else 0.0,
        risk_at_stop_inr=(round(float(qty) * (float(reference_price) - float(stop_price)), 2)
                          if qty and stop_price is not None
                          and reference_price > stop_price else None),
        expected_holding_sessions=(hold_lo, hold_hi),
        expected_holding_weeks=(max(hold_lo // 5, 1), max(hold_hi // 5, 1)),
        exit_conditions=exits,
        estimated_round_trip_cost_bps=round(cost_bps, 1) if cost_bps else None,
        estimated_impact_bps=round(impact_bps, 1) if impact_bps else None,
        liquidity_ratio_recent=liquidity_ratio,
        liquidity_warning=liquidity_warning,
        liquidity_state=liquidity_state,
        notes=notes,
    )


# =============================================================================
def _round_paise(value: float, params) -> float:
    step = iv(params.stage6_entry.entry_zone.round_to_paise) / 100.0
    return round(round(value / step) * step, 2) if step > 0 else round(value, 2)


def _resistance(frame, lookback: int, reference: float) -> Optional[float]:
    highs = pd.to_numeric(frame.get("high"), errors="coerce").dropna().tail(lookback)
    if highs.empty:
        return None
    above = highs[highs > reference]
    return float(above.min()) if not above.empty else None


def _relative_vol(frame, lookback: int) -> Optional[float]:
    closes = pd.Series(frame["close"].to_numpy(dtype="float64"))
    sigma = realised_volatility(closes, window=min(lookback, max(len(closes) - 1, 2)))
    s = sigma.dropna()
    return float(s.iloc[-1]) if not s.empty else None


def _category(score: float, rel_vol: Optional[float], cfg) -> RiskCategory:
    if score >= fv(cfg.risk_category.standard_min_score):
        return RiskCategory.STANDARD
    if score >= fv(cfg.risk_category.reduced_min_score):
        return RiskCategory.REDUCED
    return RiskCategory.MINIMUM


_CATEGORY_FRACTION = {
    RiskCategory.STANDARD: 1.0,
    RiskCategory.REDUCED: 0.6,
    RiskCategory.MINIMUM: 0.3,
}


#: Sessions in the short liquidity window, and the fraction of the trailing
#: average below which the divergence is worth the operator's attention.
_RECENT_LIQUIDITY_SESSIONS = 5
_LIQUIDITY_ALERT_RATIO = 0.5


def _recent_liquidity(frame, adtv_inr, cfg) -> Tuple[Optional[float], Optional[str]]:
    """Short-window turnover against the trailing average used for sizing."""
    if adtv_inr is None or not np.isfinite(float(adtv_inr)) or float(adtv_inr) <= 0:
        return None, None
    if frame is None or "turnover" not in frame.columns:
        return None, None
    recent = pd.to_numeric(frame["turnover"], errors="coerce").tail(
        _RECENT_LIQUIDITY_SESSIONS
    ).dropna()
    if len(recent) < _RECENT_LIQUIDITY_SESSIONS:
        return None, None
    ratio = float(recent.median()) / float(adtv_inr)
    if not np.isfinite(ratio):
        return None, None
    if ratio >= _LIQUIDITY_ALERT_RATIO:
        return round(ratio, 3), None
    warning = (
        f"LIQUIDITY: last {_RECENT_LIQUIDITY_SESSIONS} sessions traded "
        f"{ratio:.0%} of the 21-session average this position was sized on. "
        f"The size that fit the trailing window may not fit the market now."
    )
    return round(ratio, 3), warning


def _position_size(price, risk_per_share, adtv, category, params, costs
                   ) -> Tuple[int, List[str], Dict[str, float], str]:
    """Smallest of: risk budget, capital slot, liquidity cap.

    UNKNOWN LIQUIDITY SIZES TO ZERO. It used to fall back to `qty_slot`, so a
    name with no measurable ADTV was simply never liquidity-constrained and
    took the full capital slot -- while the cost model, for the same name,
    returned the cheapest fill it could produce. An absence of information
    bought the largest position and the best execution assumption in the engine.

    `liquidity.assess` distinguishes MISSING from INVALID from a real reading
    that has gone stale, because they license different actions and collapsing
    them is what made the old fallback look reasonable.
    """
    notes: List[str] = []
    capital = fv(params.capital.total_capital_inr)
    slot = float(params.capital.position_value_inr())
    risk_pct = fv(params.capital.risk_per_trade_pct)

    frac = _CATEGORY_FRACTION[category]
    risk_budget = capital * (risk_pct / 100.0) * frac
    qty_risk = int(risk_budget / risk_per_share) if risk_per_share > 0 else 0
    qty_slot = int((slot * frac) / price) if price > 0 else 0

    cap_pct = fv(params.capital.max_participation_of_adtv)
    view = assess(adtv)
    if view.adtv_inr is None or price <= 0:
        qty_liq = 0
        notes.append(
            f"NOT SIZED. {view.describe()} A position cannot be sized against a "
            f"liquidity nobody measured, and the engine will not substitute the "
            f"capital slot for one -- that would award the largest position "
            f"available to the name it knows least about."
        )
    else:
        qty_liq = int((view.adtv_inr * cap_pct) / price)
        if view.state is not LiquidityState.KNOWN_VALID:
            notes.append(f"Liquidity is {view.describe()}")

    qty = max(min(qty_risk, qty_slot, qty_liq), 0)
    binding = min(
        [("risk budget", qty_risk), ("capital slot", qty_slot), ("liquidity cap", qty_liq)],
        key=lambda x: x[1],
    )[0]
    notes.append(
        f"Size {qty:,} shares (Rs {qty*price:,.0f}). Binding constraint: {binding}. "
        f"Risk category {category.value} scales the budget to {frac:.0%}."
    )
    if binding == "liquidity cap" and qty > 0:
        notes.append(
            "Liquidity is the binding constraint, not conviction. The statistically "
            "attractive size is not executable here without moving the price."
        )
    return qty, notes, {
        "qty_by_risk": float(qty_risk), "qty_by_slot": float(qty_slot),
        "qty_by_liquidity": float(qty_liq), "risk_budget_inr": round(risk_budget, 2),
    }, view.state.value


def _exit_hierarchy(cfg, stop, invalidation, t1, t2) -> List[ExitCondition]:
    """Ordered. Thesis invalidation outranks the stop deliberately.

    `priority` is a STABLE IDENTIFIER of the rung, not a position in the list.
    Four rungs now ship disarmed, so the returned list starts at 2 and has gaps,
    and that is the correct behaviour: the config promises the switches can
    disable a rung and never reorder one, and renumbering on the fly would make
    rung 1 mean "invalidation" on one config and "the stop" on another -- so two
    runs could not be compared, and a recorded outcome could not say which rule
    it was scored under.

    The CARD renumbers for display, because a reader looking at "2., 3., 5., 8."
    reasonably wonders what happened to 1, 4, 6 and 7. Stage 8 enumerates the
    positions it prints and names the disarmed rungs explicitly underneath.
    """
    h = cfg.exit_hierarchy
    out: List[ExitCondition] = []
    spec = [
        (h.thesis_invalidation, ExitReason.THESIS_INVALIDATION, 1,
         "the reason for the trade is gone, regardless of price", invalidation),
        (h.stop_loss_breach, ExitReason.STOP_LOSS_BREACH, 2, "protective stop breached", stop),
        (h.new_hard_rejection, ExitReason.NEW_HARD_REJECTION, 3,
         "a Stage 3/5 hard gate now fails", None),
        (h.severe_regime_change, ExitReason.SEVERE_REGIME_CHANGE, 4,
         "regime moved to a no-new-entry bucket", None),
        (h.signal_reversal, ExitReason.SIGNAL_REVERSAL, 5,
         "composite rank fell below the exit percentile", None),
        (h.trailing_stop, ExitReason.TRAILING_STOP, 6, "trailing stop hit", None),
        (h.target_achieved, ExitReason.TARGET_ACHIEVED, 7, "target reached", t2),
        (h.time_expiration, ExitReason.TIME_EXPIRATION, 8,
         # NO LONGER A BACKSTOP, and the description had to stop saying so.
         # With the target and the invalidation disarmed, 39% of positions reach
         # this limit; they win 69% of the time and average +16.1% net against
         # +3.3% for the ones released by the rank band. It is where the return
         # comes from, and a card calling it a last resort would tell a holder
         # the opposite of what the measurement says.
         "maximum holding period reached -- the exit most winners take", None),
    ]
    for enabled, reason, prio, desc, level in spec:
        if bv(enabled):
            out.append(ExitCondition(reason=reason, priority=prio, description=desc, level=level))
    return out
